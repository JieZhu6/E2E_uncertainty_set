import numpy as np
from scipy.sparse import lil_matrix, csc_matrix
from scipy.sparse.linalg import spsolve, splu
import matplotlib.pyplot as plt

def build_topology(branch, n_bus):
    m = branch.shape[0]
    parent = -np.ones(n_bus, dtype=int)
    children = [[] for _ in range(n_bus)]
    r = np.zeros(m)
    x = np.zeros(m)
    branch_order = []

    for e in range(m):
        f = int(branch[e, 0]) - 1  # 转换为 0-based
        t = int(branch[e, 1]) - 1  # 转换为 0-based
        r[e] = branch[e, 2]
        x[e] = branch[e, 3]
        parent[t] = f
        children[f].append(t)
        branch_order.append((f, t))

    return parent, children, r, x, branch_order



import numpy as np

def compute_voltage_sensitivity_distflow_linearized(branch, n_bus, P, Q, lmbd, v, slack=0):
    """
    Compute voltage sensitivity matrices ∂v/∂p and ∂v/∂q using exact Jacobian 
    of the nonlinear AC DistFlow equations (v = |V|^2).

    Inputs:
      branch: (m, 4) array [from, to, r, x], from/to are floats (bus indices start at 1)
      n_bus : int, number of buses
      P, Q  : (m,) arrays, active/reactive power flows (from->to direction)
      lmbd  : (m,) array, squared current ℓ = |I|^2 on branches
      v     : (n_bus,) array, squared voltage magnitude |V|^2 at buses
      slack : int, index of slack bus (default 0)

    Returns:
      dVdp : (n_bus, n_bus) sensitivity ∂v_i / ∂p_j (excluding slack in solve, but result includes slack=0)
      dVdq : (n_bus, n_bus) sensitivity ∂v_i / ∂q_j
    """
    branch = np.array(branch)
    m = branch.shape[0]

    # Convert from/to to 0-based integer indices
    fb = np.round(branch[:, 0] - 1).astype(int)  # from bus (0-based)
    tb = np.round(branch[:, 1] - 1).astype(int)  # to bus (0-based)
    r = branch[:, 2]
    x = branch[:, 3]
    z2 = r**2 + x**2  # |z|^2

    # Build tree structure: children and parent
    children = [[] for _ in range(n_bus)]
    parent_branch = [-1] * n_bus  # parent branch index for each bus
    for idx in range(m):
        f, t = fb[idx], tb[idx]
        children[f].append(t)
        parent_branch[t] = idx

    # Map: bus j -> all upstream branches from j to root
    def path_to_root(j):
        path = []
        cur = j
        while cur != slack:
            br_idx = parent_branch[cur]
            if br_idx == -1:
                break
            path.append(br_idx)
            cur = fb[br_idx]  # move upstream
        return path  # from j to root

    # Get all non-slack buses
    non_slack = [i for i in range(n_bus) if i != slack]
    n_ns = len(non_slack)
    idx_map = {bus: idx for idx, bus in enumerate(non_slack)}  # map bus to index in non-slack vector

    # Precompute: for each branch, which node injections affect P_br, Q_br?
    # P_br = sum of p_j for j in downstream of this branch
    dPdp = np.zeros((m, n_bus))  # ∂P_ij / ∂p_k
    dQdq = np.zeros((m, n_bus))  # ∂Q_ij / ∂q_k
    dPdq = np.zeros((m, n_bus))  # ∂P_ij / ∂q_k = 0 (assumed)
    dQdp = np.zeros((m, n_bus))  # ∂Q_ij / ∂p_k = 0

    for br_idx in range(m):
        j = tb[br_idx]  # 'to' bus is the start of downstream
        # Find all downstream buses (including j)
        downstream = []
        stack = [j]
        while stack:
            node = stack.pop()
            downstream.append(node)
            stack.extend(children[node])
        # P_ij depends on p_k for all k in downstream
        for k in downstream:
            dPdp[br_idx, k] = 1.0
            dQdq[br_idx, k] = 1.0

    # Build Jacobian ∂r_i / ∂v_j for i,j in non_slack
    # r_i: voltage equation at bus i: v_i - v_parent + 2(rP + xQ) - z2*(P^2+Q^2)/v_i = 0
    J = np.zeros((n_ns, n_ns))  # ∂r_i / ∂v_j
    dRdp = np.zeros((n_ns, n_bus))  # ∂r_i / ∂p_j (used as RHS)
    dRdq = np.zeros((n_ns, n_bus))  # ∂r_i / ∂q_j

    for i in non_slack:
        br_idx = parent_branch[i]  # branch feeding bus i
        if br_idx == -1:
            continue  # should not happen for non-slack

        fi, ti = fb[br_idx], tb[br_idx]
        assert ti == i
        Ri, Xi = r[br_idx], x[br_idx]
        Pi, Qi = P[br_idx], Q[br_idx]
        vi = v[i]
        z2i = z2[br_idx]

        # Residual: r_i = v_i - v_fi + 2(Ri*Pi + Xi*Qi) - z2i*(Pi^2 + Qi^2)/v_i
        # ∂r_i / ∂v_i = 1 + z2i*(Pi^2 + Qi^2)/vi^2
        dvi_term = 1.0 + z2i * (Pi**2 + Qi**2) / (vi**2)
        if i in idx_map:
            J[idx_map[i], idx_map[i]] += dvi_term

        # ∂r_i / ∂v_fi = -1 (but fi may be slack or not)
        if fi != slack and fi in idx_map:
            J[idx_map[i], idx_map[fi]] -= 1.0

        # Coupling through Pi, Qi: ∂r_i / ∂Pi = 2*Ri - 2*z2i*Pi / vi
        dPi_term = 2*Ri - 2*z2i*Pi / vi
        # ∂r_i / ∂Qi = 2*Xi - 2*z2i*Qi / vi
        dQi_term = 2*Xi - 2*z2i*Qi / vi

        # Now: ∂r_i / ∂p_j = dPi_term * ∂Pi/∂p_j + dQi_term * ∂Qi/∂p_j
        # But ∂Qi/∂p_j = 0, so:
        dRdp[idx_map[i], :] += dPi_term * dPdp[br_idx, :]
        dRdq[idx_map[i], :] += dQi_term * dQdq[br_idx, :]

        # Also, Pi and Qi depend on p_j, q_j → affects r_i
        # But we already included via dPdp etc.

    # Now solve: J @ (∂v_ns / ∂p_j) = - ∂r_ns / ∂p_j  for each j
    dVdp = np.zeros((n_bus, n_bus))
    dVdq = np.zeros((n_bus, n_bus))

    # Set slack sensitivity = 0
    dVdp[slack, :] = 0.0
    dVdq[slack, :] = 0.0

    if n_ns > 0:
        J_inv = np.linalg.inv(J)

        for j in range(n_bus):
            rhs_p = -dRdp[:, j]  # -∂r/∂p_j
            rhs_q = -dRdq[:, j]  # -∂r/∂q_j

            dvdp_ns = J_inv @ rhs_p
            dvdq_ns = J_inv @ rhs_q

            for idx, bus in enumerate(non_slack):
                dVdp[bus, j] = dvdp_ns[idx]
                dVdq[bus, j] = dvdq_ns[idx]

    return dVdp, dVdq


def forward_backward_distflow(branch, n_bus, P_inj, Q_inj, v0=1.0, tol=1e-6, max_iter=100):
    """
    Forward-Backward Sweep for radial AC DistFlow
    branch: (m x 4) array [from_bus, to_bus, r, x]
    P_inj, Q_inj: nodal injections (load negative)
    v0: slack bus voltage
    """
    m = branch.shape[0]
    # 调整索引
    f_bus = branch[:, 0].astype(int) - 1
    t_bus = branch[:, 1].astype(int) - 1
    r = branch[:, 2]
    x = branch[:, 3]

    # 初始化
    V = np.ones(n_bus) * v0
    P_br = np.zeros(m)
    Q_br = np.zeros(m)

    for _ in range(max_iter):
        V_old = V.copy()

        # Backward sweep: compute branch flows
        for e in reversed(range(m)):
            t = t_bus[e]
            f = f_bus[e]
            P_br[e] = P_inj[t]
            Q_br[e] = Q_inj[t]
            # 累加子节点的功率
            for e2 in range(m):
                if f_bus[e2] == t:
                    P_br[e] += P_br[e2] + r[e2] * (P_br[e2]**2 + Q_br[e2]**2) / V[t]**2
                    Q_br[e] += Q_br[e2] + x[e2] * (P_br[e2]**2 + Q_br[e2]**2) / V[t]**2

        # Forward sweep: update voltages
        V[0] = v0
        for e in range(m):
            f = f_bus[e]
            t = t_bus[e]
            V[t] = V[f] - (r[e]*P_br[e] + x[e]*Q_br[e]) / V[f]

        if np.max(np.abs(V - V_old)) < tol:
            break

    return V




def validate_and_plot(dVdp, dVdq, base_V, delta_P, delta_Q, P_inj, Q_inj ,branch, n_bus):
    """
    Compare sensitivity-based voltage prediction vs actual DistFlow result and visualize.
    
    Parameters:
    dVdp, dVdq : ndarray, shape (n_bus, n_bus)
        Voltage sensitivity matrices
    base_V : ndarray
        Original voltages
    delta_P, delta_Q : ndarray
        Perturbations in nodal injections
    branch : ndarray
        Branch data
    n_bus : int
        Number of buses
    """
    # Sensitivity-based prediction
    predicted_V = base_V + dVdp @ delta_P + dVdq @ delta_Q
    
    actual_V = forward_backward_distflow(branch, n_bus, P_inj, Q_inj, v0=np.sqrt(base_V[0]))
    
    # Compute error
    error = actual_V - predicted_V
    
    # Visualization
    fig, axs = plt.subplots(1, 3, figsize=(18, 5))
    
    # Voltage comparison
    axs[0].plot(range(n_bus), np.sqrt(base_V), 'k--', label='Base')
    axs[0].plot(range(n_bus), np.sqrt(predicted_V), 'b-', label='Predicted')
    axs[0].plot(range(n_bus), actual_V, 'r-', label='Actual')
    axs[0].set_title('Voltage Comparison')
    axs[0].set_xlabel('Bus')
    axs[0].set_ylabel('Voltage (pu)')
    axs[0].legend()
    
    # Heatmap of absolute error
    im = axs[1].imshow(np.abs(error).reshape(-1, 1), cmap='hot', aspect='auto')
    axs[1].set_title('Absolute Error (|Actual - Predicted|)')
    axs[1].set_yticks(range(n_bus))
    axs[1].set_yticklabels(range(n_bus))
    plt.colorbar(im, ax=axs[1])
    
    # Bar chart of error
    axs[2].bar(range(n_bus), error)
    axs[2].set_title('Error per Bus')
    axs[2].set_xlabel('Bus')
    axs[2].set_ylabel('Error (pu)')
    
    plt.tight_layout()
    plt.show()
    
    return predicted_V, actual_V, error
