import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
import numpy as np

# 椭圆中心
center = (0, 0)

# 不同集合的宽度和高度
widths = [2.5, 2.0, 1.5, 1.0]
heights = [1.8, 1.5, 1.2, 0.8]

# 标签和颜色（亮蓝色渐变）
labels = ['RO Set', '99% CI', '95% CI', '90% CI']
colors = ['#1f77b4', '#4fa3d1', '#82c4e8', '#c6e7f4']  # 深到浅蓝

fig, ax = plt.subplots(figsize=(6, 6))

# ====== 生成历史样本 ======
np.random.seed(42)  # 固定随机种子
mean = [0, 0]
cov = [[0.03, 0.3], [0.3, 0.03]]  # 协方差矩阵，控制相关性
samples = np.random.multivariate_normal(mean, cov, size=500)

# 绘制样本点
ax.scatter(samples[:, 0], samples[:, 1], s=15, color='gray', alpha=0.5, label='Historical Samples')

# 绘制椭圆
for w, h, label, color in zip(widths, heights, labels, colors):
    ellipse = Ellipse(xy=center, width=w, height=h,
                      edgecolor='black', facecolor=color,
                      alpha=0.6, label=label)
    ax.add_patch(ellipse)

# ====== 自适应坐标范围 ======
# 样本点范围
x_min, x_max = samples[:, 0].min(), samples[:, 0].max()
y_min, y_max = samples[:, 1].min(), samples[:, 1].max()

# 椭圆最大范围
ellipse_x_max = center[0] + max(widths) / 2
ellipse_y_max = center[1] + max(heights) / 2
ellipse_x_min = center[0] - max(widths) / 2
ellipse_y_min = center[1] - max(heights) / 2

# 综合取范围
x_min = min(x_min, ellipse_x_min)
x_max = max(x_max, ellipse_x_max)
y_min = min(y_min, ellipse_y_min)
y_max = max(y_max, ellipse_y_max)

# 加边距 10%
x_margin = (x_max - x_min) * 0.1
y_margin = (y_max - y_min) * 0.1

ax.set_xlim(x_min - x_margin, x_max + x_margin)
ax.set_ylim(y_min - y_margin, y_max + y_margin)

# 坐标轴和标题
ax.set_xlabel('PV Power (p.u.)', fontsize=12)
ax.set_ylabel('WT Power (p.u.)', fontsize=12)
# ax.set_title('Uncertainty Sets with Historical Samples', fontsize=14)
ax.axhline(0, color='black', linewidth=0.8)
ax.axvline(0, color='black', linewidth=0.8)

# 图例
ax.legend(loc='upper right')
ax.set_aspect('equal')

plt.show()

