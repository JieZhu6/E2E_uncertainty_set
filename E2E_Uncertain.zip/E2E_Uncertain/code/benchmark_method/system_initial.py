#数据生成模块
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import os
np.random.seed(43)
#矩阵和向量插值
def linear_interpolation(original_sequence, target_length):
    step = (len(original_sequence) - 1) / (target_length - 1)
    expanded_sequence = []
    for i in range(target_length):
        index = i * step
        lower_index = int(index)
        upper_index = min(lower_index + 1, len(original_sequence) - 1)
        weight = index - lower_index
        interpolated_value = (1 - weight) * original_sequence[lower_index] + weight * original_sequence[upper_index]
        expanded_sequence.append(interpolated_value)
    return np.array(expanded_sequence)
def linear_interpolation_matrix(original_matrix, target_length):
    num_rows, num_cols = original_matrix.shape
    step = (num_cols - 1) / (target_length - 1)
    expanded_matrix = np.empty((num_rows, target_length))
    for i in range(num_rows):
        for j in range(target_length):
            index = j * step
            lower_index = int(index)
            upper_index = min(lower_index + 1, num_cols - 1)
            weight = index - lower_index
            interpolated_value = (1 - weight) * original_matrix[i, lower_index] + weight * original_matrix[i, upper_index]
            expanded_matrix[i, j] = interpolated_value
    return np.array(expanded_matrix)
os.makedirs('../system_data', exist_ok=True)
l = 96 #仿真时间长度
TEST_HOUR = 96
RESDATE = pd.read_excel("../system_data/forecastdata.xlsx")  #可再生能源数据
rateRES = 1
rateLOAD = 0.4
import matplotlib.pyplot as plt
from matplotlib import rcParams
import numpy as np
config = {
    "font.family":'serif',
    "font.size": 18,
    "mathtext.fontset":'stix',
    "font.serif": ['SimSun'],
}


plt.rcParams.update(config)
def res_forecast_data(TEST_HOUR,PV_num):
    np.random.seed(0)
    res_value = np.zeros((TEST_HOUR,PV_num))
    for i in range(PV_num):
        res_value[:,i] = linear_interpolation(np.array(RESDATE.iloc[3,1:])*np.random.uniform(0.9,1.1) , TEST_HOUR) * rateRES
    PV_capcity = (np.max(res_value)*1.3)
    return res_value,PV_capcity

def case33():
    # bus = np.array(pd.read_excel("D:/桌面文件夹/TBSI/Distribution network risk assessment considering source-load uncertainty/data/testdata/bus.xlsx"))
    bus = np.array(pd.read_excel("../system_data/bus_simplified.xlsx"))
    branch = np.array(pd.read_excel("../system_data/brach.xlsx"))
    r_x_ratio = 0.011 # 0.0035
    branch[:,2:4] = branch[:,2:4] *  r_x_ratio #阻抗缩放系数  # 0.01#阻抗缩放系数  # 0.01 #阻抗缩放系数  # 0.01
    # branch = np.array(pd.read_excel("D:/桌面文件夹/TBSI/Distribution network risk assessment considering source-load uncertainty/data/testdata/branch_connected.xlsx"))
    ppc = {"version": '2'}

    ##-----  Power Flow Data  -----##
    ## system MVA base
    ppc["baseMVA"] = 1.0

    ## bus data
    # bus_i type Pd Qd Gs Bs area Vm Va baseKV zone Vmax Vmin
    """
    bus type PQ bus = 1, PV bus = 2, reference bus =3,isolated bus = 4
    [节点编号，节点类别,有功需求，无功需求,分流电导(V=1.0 p.u.时所需的MW),分流电纳(V=1.0 p.u.时注入的MVAr),区域编号,电压幅值，
    电压相角,base voltage,loss zone,最大电压幅值，最小电压幅值]
    """
    ppc["bus"] = bus

    ## branch data
    # fbus, tbus, r, x, b, rateA, rateB, rateC, ratio, angle, status, angmin, angmax
    """
    来自哪个节点，去到哪个节点，电阻，电抗，total line charging susceptance,MVA rating A (long term rating)
    MVA rating B (short term rating),MVA rating C (emergency rating),变压器关断标称匝数比(线路为0),变压器移相角
    ，线路活动状态，最小角度差，最大角度差
    """
    ppc["branch"] = branch
    return ppc


def forecast_load(TEST_HOUR):
    # 标准算例中各节点负荷的比例
    bus = np.array(case33()['bus'])
    LOADDATE = linear_interpolation_matrix(np.array(pd.read_excel("../system_data/baseload.xlsx"))[:,1:],TEST_HOUR)
    load_ratio = bus[:,2]/np.sum(bus[:,2])
    active_load,reactive_load = np.zeros((TEST_HOUR,bus.shape[0])),np.zeros((TEST_HOUR,bus.shape[0]))
    for i in range(TEST_HOUR):
        active_load[i] = load_ratio*LOADDATE[0][i]
        reactive_load[i] = load_ratio*LOADDATE[1][i]
    return active_load.T*rateLOAD,reactive_load.T*rateLOAD

def forecast_price(TEST_HOUR):
    PRICE = np.array([item for item in np.array(RESDATE.iloc[4,1:]) for _ in range(1)])
    RESERVE_PRICE = np.array([item for item in np.array(RESDATE.iloc[5,1:]) for _ in range(1)])
    PRICE = linear_interpolation(PRICE, TEST_HOUR)
    RESERVE_PRICE = linear_interpolation(RESERVE_PRICE, TEST_HOUR)
    return PRICE*8,RESERVE_PRICE*9

def Y_bus_matrix():
    SYSTEM_DATA = case33()
    #节点和系统参数
    branch = np.array(SYSTEM_DATA['branch'])
    bus = np.array(SYSTEM_DATA['bus'])
    #生成阻抗矩阵 
    branch_r_x = np.zeros((branch.shape[0],4))
    branch_r_x[:,0:2] = branch [:,0:2]
    branch_r_x[:,2] = branch [:,2]
    branch_r_x[:,3] = branch [:,3]
    branch_r_x[:,2:4] = branch_r_x[:,2:4] #把阻抗标幺值调小100倍
    R_ij_matrix = np.inf*np.ones((bus.shape[0],bus.shape[0]))
    X_ij_matrix = np.inf*np.ones((bus.shape[0],bus.shape[0]))
    for i in range(branch_r_x.shape[0]):
        R_ij_matrix[int(branch_r_x[i,0])-1,int(branch_r_x[i,1])-1] = branch_r_x[i,2]
        R_ij_matrix[int(branch_r_x[i,1]-1),int(branch_r_x[i,0])-1] = branch_r_x[i,2]
        X_ij_matrix[int(branch_r_x[i,0]-1),int(branch_r_x[i,1])-1] = branch_r_x[i,3]
        X_ij_matrix[int(branch_r_x[i,1]-1),int(branch_r_x[i,0])-1] = branch_r_x[i,3] 
    return R_ij_matrix,X_ij_matrix   

def PV_bus_define():
    # PV_bus = np.array([12,18,22,25,29,33])
    PV_bus = np.array([13,18,30,33])
    return PV_bus

def draw(): #画图
    Basepower = 1
    TEST_HOUR = l
    PV_bus = PV_bus_define()
    ACTIVE_LOAD,REACTIVE_LOAD = np.array(forecast_load(l))/Basepower # 转化为标幺值
    load = np.vstack((np.sum(ACTIVE_LOAD,axis=0),np.sum(REACTIVE_LOAD,axis=0)))
    PV_p_forecast,PV_capcity = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据
    # pd.DataFrame(res).to_csv("D:/desk/TBSI/CSEE_2024-2/上传数据集/res.csv")
    # pd.DataFrame(load).to_csv("D:/desk/TBSI/CSEE_2024-2/上传数据集/load.csv")
    # pd.DataFrame(ENERGY_PRICE).to_csv("D:/desk/TBSI/CSEE_2024-2/上传数据集/ENERGY_PRICE.csv")
    plt.figure()
    plt.plot(np.arange(TEST_HOUR),np.sum(ACTIVE_LOAD, axis=0),label = 'total load')
    plt.plot(range(TEST_HOUR),np.sum(PV_p_forecast, axis=1),label = '总的可再生能源出力')
    plt.xlabel("time (h)")
    plt.ylabel("power (MW)")
    plt.legend()
    # plt.figure()
    # plt.step(np.arange(TEST_HOUR),ENERGY_PRICE/7,label = 'energy price')
    # plt.step(range(TEST_HOUR),RESERV_PRICE/7,label = '备用价格')
    # plt.xlabel("time (h)")
    # plt.ylabel("价格 ("+"元"+"/MW)")
    # # plt.ylim(25,76)
    # plt.legend()
    plt.show()



if __name__ == "__main__":
    ACTIVE_LOAD,REACTIVE_LOAD = np.array(forecast_load(l))
    load = np.vstack((np.sum(ACTIVE_LOAD,axis=0),np.sum(REACTIVE_LOAD,axis=0)))
    ENERGY_PRICE,RESERV_PRICE = np.array(forecast_price(l))
    ENERGY_PRICE = ENERGY_PRICE.reshape(TEST_HOUR)/7
    RESERV_PRICE = RESERV_PRICE.reshape(TEST_HOUR)/7
    price = np.vstack((ENERGY_PRICE,RESERV_PRICE))
    draw()