import argparse
from collections.abc import Collection
import os
from typing import Any
import random
import numpy as np
import pandas as pd
import torch
from tqdm.auto import tqdm

from PICNN_model import PICNN
from PICNN_e2e import train_e2e
from utils.data import get_loaders, get_tensors
from PICNN_problem import ProblemPICNN
from utils.parse_args import parse_args
from benchmark_method.system_initial import Y_bus_matrix,PV_bus_define
os.makedirs('../data', exist_ok=True)
train_dataset = np.load('../training_dataset/train_dataset.npy')
R_ij_matrix,X_ij_matrix = Y_bus_matrix() #节点导纳矩阵
PV_bus = PV_bus_define()
# 这里INPUT_DIM是协信息的输入维度，U_DIM是不确定性维度
BUS_NUM  = R_ij_matrix.shape[0]  # 节点数
U_DIM = len(PV_bus)  # 不确定性维度
INPUT_DIM = 2*(3*U_DIM+U_DIM) # 协变量维度
# 训练次数/batch_size/隐藏层的层数和神经元的数量
MAX_E2E_EPOCHS = 150
BATCH_SIZE = 64
SEEDS = range(10)
N_LAYERS = 2
HIDDEN_DIM = 16

def e2e_single( alpha: float, lr: float, l2reg: float, n_layers: int, hidden_dim: int,shuffle: bool, basename: str, out_dir: str,seed = 1) -> tuple[dict[str, Any], str]:
    tensors = get_tensors(shuffle=shuffle)
    # 储存一下测试集数据用于验证与其他方法的区别
    np.save('../training_dataset/y_test.npy', tensors['y_test'].detach().cpu().numpy())
    np.save('../training_dataset/initial_y_test.npy', tensors['initial_y_test'].detach().cpu().numpy())
    np.save('../training_dataset/y_test.npy', tensors['y_train'].detach().cpu().numpy())
    np.save('../training_dataset/initial_y_train.npy', tensors['initial_y_train'].detach().cpu().numpy())
    loaders = get_loaders(tensors, batch_size=BATCH_SIZE)
    rng = np.random.default_rng(seed)
    result: dict[str, Any] = {'seed': seed}
    # 加载基于PICNN定义的优化问题
    prob = ProblemPICNN(u_dim = U_DIM, bus_num = BUS_NUM, L=n_layers, d=hidden_dim)
    # 构建PICNN模型
    model = PICNN(input_dim=INPUT_DIM, u_dim=U_DIM, hidden_dim=hidden_dim, n_layers=n_layers)
    # 进行端到端训练
    model, train_result = train_e2e(model, loaders, alpha=alpha, max_epochs=MAX_E2E_EPOCHS, lr=lr, l2reg=l2reg,prob=prob, rng=rng)
    result |= train_result

    # save model
    ckpt_path = os.path.join(out_dir, f'{basename}.pt')
    torch.save(model.cpu().state_dict(), ckpt_path)

    msg = (f'best loss {result["train_task_loss"]:.4f}, 'f'best epoch {result["best_epoch"]}')
    return result, msg


def e2e( alpha: float, lr: float, l2reg: float, n_layers: int, hidden_dim: int, shuffle: bool, out_dir: str) -> None:
    """
    Args:
        alpha: risk level in (0, 1), the uncertainty set is a (1-alpha)-confidence set
        lr: learning rate
        l2reg: L2 regularization strength
        n_layers: # of hidden layers in PICNN
        hidden_dim: # of units per hidden layer
        large_q_penalty: weight for penalizing large q values
        shuffle: whether to shuffle dataset before splitting into train/calib/test
        out_dir: where to save the results
    """
    L = n_layers
    d = hidden_dim

    basename = f'e2e_a{alpha:.2f}_L{L}_d{d}'

    results = []
    result, msg = e2e_single(alpha=alpha, lr=lr, l2reg=l2reg, n_layers=L,hidden_dim=d, shuffle=shuffle,basename=basename, out_dir=out_dir)
    print(msg)

def main(args: argparse.Namespace) -> None:
    tag = args.tag
    shuffle = args.shuffle  # 是否打乱数据排序
    out_dir = f'result_data/'
    os.makedirs(out_dir, exist_ok=True)

    e2e(alpha=args.alpha, lr=args.lr, l2reg=args.l2reg, n_layers=N_LAYERS,hidden_dim=HIDDEN_DIM, shuffle=shuffle,out_dir=out_dir)

def set_seed(seed=42):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
if __name__ == '__main__':
    set_seed(42)  # 设置全局随机种子
    commands = ('e2e')
    args = parse_args(commands, lr=True, l2reg=True)
    print(args)
    main(args)
