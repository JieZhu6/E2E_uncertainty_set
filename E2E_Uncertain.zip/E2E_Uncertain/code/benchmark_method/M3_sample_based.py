import numpy as np
import matplotlib.pyplot as plt
import cvxpy as cp
import numpy as np
from system_initial import res_forecast_data,Y_bus_matrix,PV_bus_define
from VVC_plot_and_viocal import plot_delta_V,cal_capacity_vio_rate
import gurobipy as gp
from gurobipy import GRB
import os
import time
os.makedirs('../data', exist_ok=True)
initial_y_test = np.load('../training_dataset/initial_y_train.npy')  # 排列顺序为有功灵敏度、无功灵敏度和日前阶段的有功和无功
R_ij_matrix,X_ij_matrix = Y_bus_matrix() #节点导纳矩阵
# 这里INPUT_DIM是协信息的输入维度，U_DIM是不确定性维度
bus_num  = R_ij_matrix.shape[0]  # 节点数
TEST_HOUR = 96
PV_bus = PV_bus_define()
PV_p_forecast,PV_capcity = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据
error_dataset = np.load('../training_dataset/total_fit_data.npy')  # 预测误差的历史数据  这里的误差数据是百分比数据 最后计算的时候记得乘上基准值
# 从训练集中提取出来参数
P_V_sensitity = initial_y_test[:,:len(PV_bus) * (bus_num-1)].reshape(initial_y_test.shape[0],len(PV_bus),(bus_num-1))
Q_V_sensitity = initial_y_test[:,len(PV_bus) * (bus_num-1) : 2*(len(PV_bus) * (bus_num-1))].reshape(initial_y_test.shape[0],len(PV_bus),(bus_num-1))
day_ahead_p = initial_y_test[:,2*(len(PV_bus) * (bus_num-1)) : 2*(len(PV_bus) * (bus_num-1)) + len(PV_bus)]
day_ahead_q = initial_y_test[:,2*(len(PV_bus) * (bus_num-1)) + len(PV_bus):]
# 这里先以一个样本为例跑通优化代码
instance_num = 15
day_P,day_Q,p_v,q_v = day_ahead_p[instance_num],day_ahead_q[instance_num],P_V_sensitity[instance_num],Q_V_sensitity[instance_num]
# 目标函数辅助变量 obj_auxilary: bus_num-1 个
BIG_M = 1e3
J_Matrix = np.array([(np.sqrt(2) - 1, 1), (1, np.sqrt(2) - 1), (1, 1 - np.sqrt(2)), (np.sqrt(2) - 1, -1)])
num_samples = error_dataset.shape[0]
num_pv = len(PV_bus)

# =====================
# 建立 Gurobi 模型
# =====================
model = gp.Model("VVC_Optimization")
# model.Params.OutputFlag = 1

# 决策变量
obj_auxilary = model.addVars(bus_num - 1, name="obj_auxilary", lb=0.0)
beita_cof = model.addVars(num_pv, name="beita_cof", lb=-GRB.INFINITY)
sample_var = model.addVars(num_samples, vtype=GRB.BINARY, name="sample_var")
# 开始计时
t1 = time.time()

# 添加约束
for i in range(num_samples):
    delta_P = np.array([day_P[n] * error_dataset[i, n] for n in range(num_pv)])
    delta_Q = [delta_P[n] * beita_cof[n] for n in range(num_pv)]
    # 上下界
    for bus in range(bus_num - 1):
        total_deltaV = gp.quicksum(-p_v[j, bus] * delta_P[j] - q_v[j, bus] * delta_Q[j] for j in range(num_pv))
        model.addConstr(total_deltaV - obj_auxilary[bus] <= BIG_M * sample_var[i])
        model.addConstr(-total_deltaV - obj_auxilary[bus] <= BIG_M * sample_var[i])
    # PV 容量约束
    for n in range(num_pv):
        combined = [day_P[n] + delta_P[n], day_Q[n] + delta_Q[n]]
        for r in range(J_Matrix.shape[0]):
            expr_pv = J_Matrix[r, 0] * combined[0] + J_Matrix[r, 1] * combined[1]
            model.addConstr(expr_pv - PV_capcity <= BIG_M * sample_var[i])

# 置信水平约束
model.addConstr(sample_var.sum() / num_samples <= 0.05)
t2 = time.time()
print(f"建模时间: {t2 - t1:.2f} s")
# 目标函数
model.setObjective(gp.quicksum(obj_auxilary[j] for j in range(bus_num - 1)), GRB.MINIMIZE)
# 优化
model.optimize()
print('optimal value:', model.ObjVal)
# model.write('M2.lp')
# 输出结果
beita_values_dict = model.getAttr("X", beita_cof)
print(beita_values_dict)
print(model.getAttr("X", obj_auxilary))
beita_values = np.array([beita_values_dict[n] for n in range(num_pv)])
method = 3
np.save(f'../result_data/day_P_M{method}.npy',day_P)
np.save(f'../result_data/p_v_M{method}.npy',p_v)
np.save(f'../result_data/q_v_M{method}.npy',q_v)
np.save(f'../result_data/beite_cof_M{method}.npy',beita_values)
cal_capacity_vio_rate(day_P, day_Q, beita_values)
plot_delta_V(day_P, p_v, q_v, beita_values)





