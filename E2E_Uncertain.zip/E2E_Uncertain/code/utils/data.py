import sys
import os
# 获取当前脚本的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取父目录 (即 utils 和 benchmark_method 的共同父目录)
parent_dir = os.path.dirname(current_dir)
# 将父目录添加到 sys.path 的开头
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from collections.abc import Mapping
import os
import numpy as np
import torch
from torch import Tensor  # for typing annotations
from torch.utils.data import DataLoader, TensorDataset
from benchmark_method.system_initial import PV_bus_define,Y_bus_matrix
TRAIN_CALIB_FRAC = 0.8  # out of all data, first 80% for training+calibration, last 20% for test
TRAIN_FRAC = 0.8        # of the training+calib data, use a 80% train / 20% calib split
PV_bus = PV_bus_define()
R_ij_matrix,X_ij_matrix = Y_bus_matrix()
U_DIM = len(PV_bus)  # 不确定性维度即凸输入维
BUS_DIM = R_ij_matrix.shape[0]
def get_train_test_split(y: np.ndarray, uncertain: np.ndarray, initial_y,shuffle: bool = False) -> dict[str, Tensor | np.ndarray]:
    # y是协变量，uncertain是不确定性变量即凸输入变量
    if shuffle:
        rng = np.random.default_rng(seed=100)
        inds = rng.permutation(len(y))
        y = y[inds]
        uncertain = uncertain[inds]

    n = int(y.shape[0] * TRAIN_CALIB_FRAC)
    tensors: dict[str, Tensor | np.ndarray] = {
        'y_train': torch.from_numpy(y[:n]).float(),
        'uncertain_train': torch.from_numpy(uncertain[:n]).float(),
        'initial_y_train': torch.from_numpy(initial_y[:n]).float(),
        'y_test': torch.from_numpy(y[n:]).float(),
        'uncertain_test': torch.from_numpy(uncertain[n:]).float(),
        'initial_y_test': torch.from_numpy(initial_y[n:]).float(),
    }
    return tensors



def get_loaders(tensors: Mapping[str, Tensor], batch_size: int) -> dict[str, DataLoader]:
    shuffle = True
    if batch_size == -1:
        batch_size = len(tensors['y_train'])
        shuffle = False
    train_loader = DataLoader(
        TensorDataset(tensors['y_train'], tensors['uncertain_train'], tensors['initial_y_train']),
        shuffle=shuffle, batch_size=batch_size, pin_memory=True)

    num_test = len(tensors['y_test'])
    test_loader = DataLoader(
        TensorDataset(tensors['y_test'], tensors['uncertain_test'],tensors['initial_y_test']),
        shuffle=False, batch_size=num_test, pin_memory=True)
    
    return {'train': train_loader, 'test': test_loader}


def get_tensors(shuffle: bool):
    # Load data
    os.makedirs('../data', exist_ok=True)
    train_dataset = np.load('../training_dataset/train_dataset.npy')
    uncertain = train_dataset[:, :U_DIM] # 不确定性变量信息 
    y = train_dataset[:, U_DIM: U_DIM + 2*(3*U_DIM+U_DIM)] # 经过池化后的协变量信息 
    initial_y = train_dataset[:, U_DIM + 2*(3*U_DIM+U_DIM):]
    tensors = get_train_test_split(y, uncertain, initial_y, shuffle=shuffle)
    return tensors

if __name__ == '__main__':
    tensors = get_tensors(shuffle=True)
    print(tensors['y_train'].shape)
    print(tensors['uncertain_train'].shape)
    print(tensors['initial_y_train'].shape)
    print(tensors['y_test'].shape)
    print(tensors['uncertain_test'].shape)
    print(tensors['initial_y_test'].shape)
