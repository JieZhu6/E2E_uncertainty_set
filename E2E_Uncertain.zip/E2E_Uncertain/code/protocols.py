from collections.abc import Sequence
from typing import Protocol
import torch
import cvxpy as cp
from cvxpylayers.torch import CvxpyLayer
import numpy as np
from torch import Tensor

from PICNN_problem import PICNN


class BaseProblemProtocol(Protocol):

    def __init__(self):
        self.vars = self.dual_vars
        self.constraints = self.dual_constraints
        obj = self.dual_obj
        prob = cp.Problem(cp.Minimize(obj), self.constraints)
        assert prob.is_dpp()
        self.prob = prob

    def task_loss_np(self, y: np.ndarray, is_standardized: bool) -> float:
        ...

    def task_loss_torch(
        self, y: Tensor, is_standardized: bool, solution: Sequence[Tensor]
    ) -> Tensor:
        ...

    def get_cvxpylayer(self) -> CvxpyLayer:
        # 在 self.prob = prob 之后
        print("Problem parameters with names:")
        for p in self.prob.parameters():
            print(f"  {p.name()} : shape {p.shape}, id {id(p)}")
        print("Problem parameters:", self.prob.parameters())
        print("Your params.values():", list(self.params.values()))  #检查参数是否对应
        return CvxpyLayer(self.prob,parameters=list(self.params.values()),variables=list(self.dual_vars.values()))


class PICNNProblemProtocol(BaseProblemProtocol, Protocol):
    def solve(self, y: np.ndarray, model: PICNN, q: float) -> cp.Problem:
        ...

    def solve_cvxpylayers(
        self, y: Tensor, model: PICNN, q: Tensor, layer: CvxpyLayer
    ) -> list[Tensor]:
        ...
