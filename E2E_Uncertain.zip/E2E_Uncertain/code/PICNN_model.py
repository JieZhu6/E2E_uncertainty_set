import torch.utils.data
from torch import nn, Tensor
from tqdm.auto import tqdm

class PICNN(nn.Module):
    """
    Partially input-convex neural network mapping from input example
    y of shape [input_dim] and uncertainty of shape [u_dim] to a scalar score output s(y, u)

    Args:
        input_dim: dimension of the input covariates
        u_dim: dimension of the uncertainty
        hidden_dim: dimension of the hidden layers (i.e., d)
        n_layers: # of hidden layers (i.e., L)
        u_in_output_layer: if False, sets V_L = 0
        epsilon: weight for ‖u‖∞ term in output layer
    """
    def __init__(self, input_dim: int, u_dim: int, hidden_dim: int, n_layers: int, u_in_output_layer: bool = True, epsilon: float = 0.,seed: int = 42):
        super().__init__()
        self.input_dim = input_dim
        self.u_dim = u_dim
        self.hidden_dim = hidden_dim
        L = n_layers
        self.L = L
        # 设置初始化种子，使得初始化参数保持一致
        # 固定随机数种子
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        # bag of tricks for feasibility
        self.epsilon = epsilon
        self.u_in_output_layer = u_in_output_layer

        null_module = nn.Module()

        self.W_hat_layers = nn.ModuleList(   
            [null_module]  # 空一层是sita_0变成0了
            + [nn.Linear(hidden_dim, hidden_dim) for _ in range(1, L+1)]
        )  # 把权重项置零，偏置项置1，就是只输入凸路径
        self.W_bar_layers = nn.ModuleList(
            [null_module]
            + [nn.Linear(hidden_dim, hidden_dim, bias=False) for _ in range(1, L)]
            + [nn.Linear(hidden_dim, 1, bias=False)]
        )
        self.V_hat_layers = nn.ModuleList(
            [nn.Linear(input_dim, u_dim)]
            + [nn.Linear(hidden_dim, u_dim) for _ in range(1, L+1)]
        ) # 把权重项置零，偏置项置1，就是只输入凸路径
        self.V_bar_layers = nn.ModuleList(
            [nn.Linear(u_dim, hidden_dim, bias=False) for _ in range(L)]
            + [nn.Linear(u_dim, 1, bias=False)]
        )
        self.b_layers = nn.ModuleList(
            [nn.Linear(input_dim, hidden_dim)]
            + [nn.Linear(hidden_dim, hidden_dim) for _ in range(1, L)]
            + [nn.Linear(hidden_dim, 1)]
        ) # 把权重项置零，偏置项置1，就是只输入凸路径
        self.u_layers = nn.ModuleList(
            [nn.Linear(input_dim, hidden_dim)]
            + [nn.Linear(hidden_dim, hidden_dim) for _ in range(1, L)]  # Used to be L+1
        )
        self.clamp_weights()

    def clamp_weights(self) -> None:
        """Clamps weights of all the W_bar layers to be ≥ 0.
        Always call this function after loss.backward().
        """
        with torch.no_grad():
            for layer in self.W_bar_layers:
                if isinstance(layer, nn.Linear):
                    layer.weight.clamp_(min=0)
            if not self.u_in_output_layer:
                self.V_bar_layers[-1].weight.fill_(0.)

    def forward(self, y: Tensor, uncertainty: Tensor) -> Tensor:
        """Computes the score for the given input examples (y, uncertainty).
        Preserves original output shape: returns output[..., 0] as in original code.
        """
        # --- 维度处理：为了兼容单样本输入 ---
        if y.dim() == 1:
            # 单个 instance: [D] -> [1, D]
            y = y.unsqueeze(0)
        if uncertainty.dim() == 1:
            uncertainty = uncertainty.unsqueeze(0)
        # 不加 squeeze_output，因为我们最后用 [..., 0]
        # print(y.shape,uncertainty.shape)
        # --- 正常前向传播 ---
        ReLU = nn.ReLU()
        u = y
        sigma = 0
        for l in range(self.L):
            if l > 0:
                W_hat_vec = ReLU(self.W_hat_layers[l](u))
                W_sigma = self.W_bar_layers[l](W_hat_vec * sigma)
            else:
                W_sigma = 0

            V_hat_vec = self.V_hat_layers[l](u)
            V_y = self.V_bar_layers[l](V_hat_vec * uncertainty)
            b = self.b_layers[l](u)
            sigma = ReLU(W_sigma + V_y + b)
            u = ReLU(self.u_layers[l](u))

        # 输出层
        l = self.L
        W_hat_vec = ReLU(self.W_hat_layers[l](u))
        W_sigma = self.W_bar_layers[l](W_hat_vec * sigma)

        V_y = 0.
        if self.u_in_output_layer:
            V_hat_vec = self.V_hat_layers[l](u)
            V_y = self.V_bar_layers[l](V_hat_vec * uncertainty)
        b = self.b_layers[l](u)

        output = W_sigma + V_y + b  # shape: [B, 1]

        if self.epsilon != 0.:
            output += self.epsilon * torch.norm(y, p=float('inf'),dim=1)

        # return output[..., 0] ---
        return output[..., 0]  # [B, 1] -> [B]


    # def forward(self, y: Tensor, uncertainty: Tensor) -> Tensor:
    #     """Computes the score for the given input examples (y,uncertainty)."""
    #     ReLU = nn.ReLU()
    #     u = y
    #     sigma = 0
    #     for l in range(self.L):
    #         if l > 0:
    #             W_hat_vec = ReLU(self.W_hat_layers[l](u))
    #             W_sigma = self.W_bar_layers[l](W_hat_vec * sigma)
    #         else:
    #             W_sigma = 0
    #         V_hat_vec = self.V_hat_layers[l](u)        # shape [batch, d]
    #         V_y = self.V_bar_layers[l](V_hat_vec * uncertainty)
    #         b = self.b_layers[l](u)
    #         sigma = ReLU(W_sigma + V_y + b)
    #         u = ReLU(self.u_layers[l](u))
    #     l = self.L
    #     W_hat_vec = ReLU(self.W_hat_layers[l](u))
    #     W_sigma = self.W_bar_layers[l](W_hat_vec * sigma)

    #     V_y = 0.
    #     if self.u_in_output_layer:
    #         V_hat_vec = self.V_hat_layers[l](u)
    #         V_y = self.V_bar_layers[l](V_hat_vec * uncertainty)
    #     b = self.b_layers[l](u)
    #     print(y.shape)
    #     output = W_sigma + V_y + b
        # if self.epsilon != 0:
        #     output += self.epsilon * torch.norm(y, p=float('inf'),dim=1)

        # return output[..., 0]
