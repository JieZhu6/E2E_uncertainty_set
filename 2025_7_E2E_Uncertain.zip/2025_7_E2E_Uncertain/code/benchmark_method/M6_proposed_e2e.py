import sys
import os
# 获取当前脚本的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取父目录 (即 utils 和 benchmark_method 的共同父目录)
parent_dir = os.path.dirname(current_dir)
# 将父目录添加到 sys.path 的开头
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
import numpy as np
import matplotlib.pyplot as plt
import cvxpy as cp
import numpy as np
import torch
from system_initial import res_forecast_data,Y_bus_matrix,PV_bus_define
from PICNN_model import PICNN
from PICNN_problem import ProblemPICNN,cal_q
from torch.utils.data import TensorDataset, DataLoader
from utils.data import get_loaders, get_tensors
from VVC_plot_and_viocal import plot_delta_V,cal_capacity_vio_rate
os.makedirs('../data', exist_ok=True)


initial_y_test = np.load('../training_dataset/initial_y_train.npy')  # 排列顺序为有功灵敏度、无功灵敏度和日前阶段的有功和无功
R_ij_matrix,X_ij_matrix = Y_bus_matrix() #节点导纳矩阵
PV_bus = PV_bus_define()
# 这里INPUT_DIM是协信息的输入维度，U_DIM是不确定性维度
bus_num  = R_ij_matrix.shape[0]  # 节点数
TEST_HOUR = 96
PV_bus = PV_bus_define()
PV_p_forecast,PV_capcity = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据

train_dataset = np.load('../training_dataset/train_dataset.npy')
# 这里INPUT_DIM是协信息的输入维度，U_DIM是不确定性维度
BUS_NUM  = R_ij_matrix.shape[0]  # 节点数
U_DIM = len(PV_bus)  # 不确定性维度
INPUT_DIM = 2*(3*U_DIM+U_DIM) # 协变量维度
# 训练次数/batch_size/隐藏层的层数和神经元的数量
MAX_E2E_EPOCHS = 100
BATCH_SIZE = 64
SEEDS = range(10)
N_LAYERS = 2
HIDDEN_DIM = 16

# 从训练集中提取出来参数
P_V_sensitity = initial_y_test[:,:len(PV_bus) * (bus_num-1)].reshape(initial_y_test.shape[0],len(PV_bus),(bus_num-1))
Q_V_sensitity = initial_y_test[:,len(PV_bus) * (bus_num-1) : 2*(len(PV_bus) * (bus_num-1))].reshape(initial_y_test.shape[0],len(PV_bus),(bus_num-1))
day_ahead_p = initial_y_test[:,2*(len(PV_bus) * (bus_num-1)) : 2*(len(PV_bus) * (bus_num-1)) + len(PV_bus)]
day_ahead_q = initial_y_test[:,2*(len(PV_bus) * (bus_num-1)) + len(PV_bus):]
"目标函数线性化的辅助变量"
obj_auxilary = cp.Variable(bus_num - 1, name='obj_auxilary', nonneg=True)
"控制策略的参数"
beita_cof =  cp.Variable(len(PV_bus), name='control policy parameter')
constr = []
# 这里先以一个样本为例跑通优化代码
instance_num = 15
day_P,day_Q,p_v,q_v = day_ahead_p[instance_num],day_ahead_q[instance_num],P_V_sensitity[instance_num],Q_V_sensitity[instance_num]
# 先读取神经网络的参数
# 加载基于PICNN定义的优化问题
prob = ProblemPICNN(u_dim = U_DIM, bus_num = BUS_NUM, L = N_LAYERS, d = HIDDEN_DIM)
# 构建PICNN模型
model = PICNN(input_dim=INPUT_DIM, u_dim=U_DIM, hidden_dim = HIDDEN_DIM, n_layers = N_LAYERS)
tensors = get_tensors(shuffle=False)
loaders = get_loaders(tensors, batch_size=BATCH_SIZE)
dataset = loaders['train'].dataset
"获取单样本 (y, uncertain, initial_y) 先以单样本作为特例测试一下" 
y_single, uncertain_single, initial_y_single = dataset[instance_num]
y_batch = y_single.unsqueeze(0)           # shape: [1, ...]
uncertain_batch = uncertain_single.unsqueeze(0)
initial_y_batch = initial_y_single.unsqueeze(0)
single_dataset = TensorDataset(y_batch, uncertain_batch, initial_y_batch)
single_loader = DataLoader(single_dataset, batch_size=1, shuffle=False)

# 调用PICNN的solve_cvxplayers进行直接求解
alpha = 0.05
y,uncertain,initial_y =  next(iter(single_loader))
# 载入PICNN得参数
out_dir = f'result_data/'
os.makedirs(out_dir, exist_ok=True)
basename = f'e2e_a{alpha:.2f}_L{prob.L}_d{prob.d}'
ckpt_path = os.path.join(out_dir, f'{basename}.pt')
model.load_state_dict(torch.load(ckpt_path, weights_only=True))
# 查看模型参数值
# for name, param in model.named_parameters():
#     numel = param.data.numel()
#     mean_val = param.data.mean().item()
#     # 使用有偏标准差，避免单元素报 nan
#     std_val = param.data.std(unbiased=False).item() if numel > 1 else 0.0
#     has_nan = torch.isnan(param.data).any().item()

#     print(f"{name}: mean={mean_val:.6f}, std={std_val:.6f}, has_nan={has_nan}")
q = cal_q(model,y, alpha)
test1,test2,test3 = y.cpu().numpy().flatten(),initial_y.cpu().numpy().flatten(),q.detach().cpu().numpy().flatten()
"获取单样本 (y, uncertain, initial_y) 先以单样本作为特例测试一下" 
# cvxpylayer = prob.get_cvxpylayer()
# solution = prob.solve_cvxpylayers(y,initial_y, model, q, cvxpylayer)

solution = prob.solve_solver(y,initial_y, model, q)

beita_values = solution[3].detach().cpu().numpy().flatten()
print('cof_value:',beita_values)
print('obj:',np.sum(solution[0].detach().cpu().numpy()))

method = 6
np.save(f'../result_data/day_P_M{method}.npy',day_P)
np.save(f'../result_data/p_v_M{method}.npy',p_v)
np.save(f'../result_data/q_v_M{method}.npy',q_v)
np.save(f'../result_data/beite_cof_M{method}.npy',beita_values)

cal_capacity_vio_rate(day_P, day_Q, beita_values)
plot_delta_V(day_P, p_v, q_v, beita_values)
