"画图函数和验证逆变器容量函数"

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap, BoundaryNorm
from system_initial import res_forecast_data,Y_bus_matrix,PV_bus_define
import os
from scipy.stats import gaussian_kde
import math
from matplotlib.colors import Normalize
plt.rcParams.update({'font.size': 15})
plt.rc('font', family='Times New Roman')
os.makedirs('../data', exist_ok=True)
initial_y_test = np.load('../training_dataset/initial_y_test.npy')  # 排列顺序为有功灵敏度、无功灵敏度和日前阶段的有功和无功
R_ij_matrix,X_ij_matrix = Y_bus_matrix() #节点导纳矩阵
# 这里INPUT_DIM是协信息的输入维度，U_DIM是不确定性维度
bus_num  = R_ij_matrix.shape[0]  # 节点数
TEST_HOUR = 96
PV_bus = PV_bus_define()
PV_p_forecast,PV_capcity = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据
error_dataset = np.load('../training_dataset/total_test_data.npy')  # 预测误差的历史数据  这里的误差数据是百分比数据 最后计算的时候记得乘上基准值

def plot_delta_V(day_P,p_v,q_v,beite_cof):  
    delta_V = np.zeros((error_dataset.shape[0], bus_num - 1))
    # 计算电压偏移量  先对于一个PV功率来看 
    for i in range(error_dataset.shape[0]):
        delta_P = day_P * error_dataset[i]
        # max_delta_Q = np.sqrt(PV_capcity**2 - (day_P+delta_P)**2)
        delta_Q = delta_P * beite_cof
        delta_voltage = p_v.T @ delta_P.reshape(-1,1) + q_v.T @ delta_Q.reshape(-1,1)
        delta_V[i] = np.abs(delta_voltage [:,0])
    num_features = delta_V.shape[1]
    # 百分位列表
    # percentile_list = [0, 5, 12.5, 25, 37.5, 45, 50, 62.5, 75, 87.5, 95, 100]
    percentile_list = [5, 12.5, 25, 37.5, 45, 50, 62.5, 75, 87.5, 95]
    # 蓝色调，从浅到深再到浅，中间最深
    # 外侧浅(0.2)、内侧深(0.8)，两侧对称
    half_colors = plt.cm.Blues(np.linspace(0.35, 0.6, len(percentile_list)))  # 外浅内深
    full_colors = np.concatenate([half_colors])  # 对称

    fig, ax = plt.subplots(figsize=(8, 5))

    # 填充百分位区间：从外到内绘制
    for i in range(len(percentile_list)-1):
        lower = percentile_list[i]
        upper = percentile_list[(i+1)]
        percentiles = np.percentile(delta_V, [lower, upper], axis=0)
        ax.fill_between(range(1, num_features+1), percentiles[0], percentiles[1],
                        color=half_colors[i], alpha=0.9)

    # 中位数线和点
    median_values = np.median(delta_V, axis=0)
    ax.plot(range(1, num_features+1), median_values, color='#08519c', linewidth=2)
    ax.scatter(range(1, num_features+1), median_values, color='#08519c', s=15)
    # 坐标轴设置
    ax.set_xlabel('Node', fontsize=14)
    ax.set_ylabel('Voltage deviation (pu)', fontsize=14)
    # ax.set_ylim(-0.0005, 0.07)

    # Colorbar（对称，50%最深）
    cmap = ListedColormap(full_colors)
    bounds = percentile_list
    norm = BoundaryNorm(bounds, cmap.N)

    cb = fig.colorbar(plt.cm.ScalarMappable(cmap=cmap, norm=norm),
                    ax=ax, ticks=percentile_list)
    cb.ax.set_yticklabels([f'{p:.1f}%' for p in percentile_list])
    cb.set_label('Percentile', fontsize=12)

    plt.tight_layout()
    plt.show()

def plot_PDF(day_P,p_v,q_v,beite_cof):
    delta_V = np.zeros((error_dataset.shape[0], bus_num - 1))
    
    # 计算电压偏移量
    for i in range(error_dataset.shape[0]):
        delta_P = day_P * error_dataset[i]
        delta_Q = delta_P * beite_cof
        delta_voltage = p_v.T @ delta_P.reshape(-1, 1) + q_v.T @ delta_Q.reshape(-1, 1)
        delta_V[i] = np.abs(delta_voltage[:, 0])

    num_features = delta_V.shape[1]
    cmap = plt.cm.Blues
    cmap = plt.cm.ScalarMappable(norm=None, cmap=plt.cm.Blues)
    custom_cmap = plt.cm.Blues(np.linspace(0.3, 0.8, 256))  # 取一段范围
    cmap = plt.cm.colors.ListedColormap(custom_cmap)
    fig, ax = plt.subplots(figsize=(8, 5))

    for j in range(num_features):
        values = delta_V[:, j]
        kde = gaussian_kde(values)

        # 取 2%-98% 的范围，避免极端值影响
        lower = np.percentile(values, 2)
        upper = np.percentile(values, 98)
        x_grid = np.linspace(lower, upper, 200)
        density = kde(x_grid)

        # 归一化密度用于颜色映射
        norm = Normalize(vmin=density.min(), vmax=density.max())

        # 分段填充颜色，密度越大越深
        for k in range(len(x_grid) - 1):
            ax.fill_between([j + 1 - 0.4, j + 1 + 0.4],
                            [x_grid[k], x_grid[k]],
                            [x_grid[k + 1], x_grid[k + 1]],
                            color=cmap(norm(density[k])),
                            alpha=0.9)

    # 画中位数
    median_values = np.median(delta_V, axis=0)
    ax.plot(range(1, num_features + 1), median_values, color='#08519c', linewidth=2)
    ax.scatter(range(1, num_features + 1), median_values, color='#08519c', s=15)

    # 坐标轴设置
    ax.set_xlabel('Node')
    ax.set_ylabel('Voltage deviation (pu)')
    # ax.set_ylim(-0.0005, 0.07)

    # 颜色条（对应密度）
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cb = fig.colorbar(sm, ax=ax)
    cb.set_label('Probability density')

    plt.tight_layout()
    plt.show()

def cal_capacity_vio_rate(day_P,day_Q,beite_cof):
    J_Matrix = np.array([(np.sqrt(2) - 1, 1), (1, np.sqrt(2) - 1), (1, 1 - np.sqrt(2)), (np.sqrt(2) - 1, -1)])
    vio_rate_individual = np.zeros(len(PV_bus)) # 单个违约
    vio_rate_joint = 0
    for i in range(error_dataset.shape[0]):
        vio_happen = False
        day_P_actual = day_P * (1+error_dataset[i])
        day_Q_actual = day_Q + (day_P * error_dataset[i]) * beite_cof
        for j in range(len(PV_bus)):
            combined = np.array([day_P_actual[j], day_Q_actual[j]]).reshape(-1,1)
            # 检验线性近似约束
            if np.max(J_Matrix @ combined) > PV_capcity:
                vio_rate_individual[j] += 1
                vio_happen = True
            # 检验平方约束
            # actual_capacity = day_P_actual[j]**2 + day_Q_actual[j] ** 2
            # if actual_capacity > PV_capcity**2:
            #     vio_rate_individual[j] += 1
        if vio_happen:
            vio_rate_joint += 1
    vio_rate_joint = vio_rate_joint/error_dataset.shape[0] * 100
    vio_rate_individual = vio_rate_individual/error_dataset.shape[0] * 100
    print(vio_rate_joint,vio_rate_individual)


def plot_multi_V(day_P_list, p_v_list, q_v_list, beite_cof_list, name_list, wspace=0.1, hspace=0.2):
    num_plots = len(day_P_list)

    # 固定2列
    cols = 2
    rows = math.ceil(num_plots / cols)

    # 创建 gridspec，最后一列留给 colorbar
    fig = plt.figure(figsize=(3.5 * cols + 1.2, 3 * rows))
    gs = fig.add_gridspec(rows, cols + 1, width_ratios=[1]*cols + [0.05])

    percentile_list = [5, 12.5, 25, 37.5, 45, 50, 62.5, 75, 87.5, 95]
    # 蓝色调，从浅到深再到浅，中间最深
    # 外侧浅(0.2)、内侧深(0.8)，两侧对称
    half_colors = plt.cm.Blues(np.linspace(0.3, 0.6, len(percentile_list)))  # 外浅内深
    full_colors = np.concatenate([half_colors])  # 对称

    cmap = ListedColormap(full_colors)
    norm = BoundaryNorm(percentile_list, cmap.N)

    axes = []
    for idx in range(num_plots):
        row = idx // cols
        col = idx % cols
        ax = fig.add_subplot(gs[row, col])
        axes.append(ax)

        day_P = day_P_list[idx]
        p_v = p_v_list[idx]
        q_v = q_v_list[idx]
        beite_cof = beite_cof_list[idx]
        name = name_list[idx]

        # 计算电压偏移量
        delta_V = np.zeros((error_dataset.shape[0], bus_num - 1))
        for i in range(error_dataset.shape[0]):
            delta_P = day_P * error_dataset[i]
            delta_Q = delta_P * beite_cof
            delta_voltage = p_v.T @ delta_P.reshape(-1, 1) + q_v.T @ delta_Q.reshape(-1, 1)
            delta_V[i] = np.abs(delta_voltage[:, 0])

        num_features = delta_V.shape[1]

        # 填充百分位区间：从外到内绘制
        for i in range(len(percentile_list)-1):
            lower = percentile_list[i]
            upper = percentile_list[(i+1)]
            percentiles = np.percentile(delta_V, [lower, upper], axis=0)
            ax.fill_between(range(1, num_features+1), percentiles[0], percentiles[1],
                            color=half_colors[i], alpha=0.9)

        # 中位数线
        median_values = np.median(delta_V, axis=0)
        ax.plot(range(1, num_features+1), median_values, color='#08519c', linewidth=1.5)
        ax.scatter(range(1, num_features+1), median_values, color='#08519c', s=12)

        percentiles = np.percentile(delta_V, 95, axis=0)
        print(f'M{idx+1}:','mean:',np.sum(median_values),'max:',np.sum(np.max(delta_V, axis=0)),'95% percentile:',np.sum(percentiles))
        # 标题
        ax.set_title(name, fontsize=14)

        # 坐标轴显示逻辑
        if row == rows - 1:  # 只在最后一行显示 xlabel
            ax.set_xlabel('Bus')
        else:
            ax.set_xticklabels([])

        if col == 0:  # 只在第一列显示 ylabel
            ax.set_ylabel('Voltage deviation (pu)')
        else:
            ax.set_yticklabels([])

        ax.set_ylim(-0.0005, 0.081)
        ax.set_xlim(1.5, 33.5)

    # 调整子图间距
    fig.subplots_adjust(wspace=wspace, hspace=hspace, right=0.88)

    # Colorbar
    cax = fig.add_subplot(gs[:, -1])
    cb = fig.colorbar(plt.cm.ScalarMappable(cmap=cmap, norm=norm), cax=cax, ticks=percentile_list)
    cb.ax.set_yticklabels([f'{p:.1f}%' for p in percentile_list])

    plt.savefig('../picture/33_voltage.png', dpi=400)
    plt.show()




if __name__ == "__main__":
    method = np.array([1, 2, 3, 4, 5, 6])
    day_P_list, p_v_list, q_v_list, beite_cof_list = [], [], [], []
    name_list = ['M1', 'M2', 'M3', 'M4', 'M5', 'M6']

    for i in method:
        day_P_list.append(np.load(f'../result_data/day_P_M{i}.npy'))
        p_v_list.append(np.load(f'../result_data/p_v_M{i}.npy'))
        q_v_list.append(np.load(f'../result_data/q_v_M{i}.npy'))
        beite_cof_list.append(np.load(f'../result_data/beite_cof_M{i}.npy'))

    # 转换为numpy数组，维度为 (len(method), ...)
    day_P_array = np.stack(day_P_list, axis=0)        # shape: (len(method), a, b)
    p_v_array = np.stack(p_v_list, axis=0)            # shape: (len(method), a, b)
    q_v_array = np.stack(q_v_list, axis=0)            # shape: (len(method), a, b)
    beite_cof_array = np.stack(beite_cof_list, axis=0)# shape: (len(method), a, b)
    
    plot_multi_V(day_P_list, p_v_list, q_v_list, beite_cof_list, name_list)