import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.optim as optim
import cvxpy as cp
from cvxpylayers.torch import CvxpyLayer
from gurobipy import Model,GRB,quicksum,MVar,concatenate
import numpy as np
from benchmark_method.system_initial import res_forecast_data,PV_bus_define,Y_bus_matrix
import time
import os
os.makedirs('../data', exist_ok=True)
"定义系统常数"
plt.rcParams.update({'font.size': 16}) # 改变所有字体大小，改变其他性质类似
plt.rc('font',family='Times New Roman')
TEST_HOUR = 96 #仿真时长
#电价、负荷数据
R_ij_matrix,X_ij_matrix = Y_bus_matrix() #节点导纳矩阵
bus_num = R_ij_matrix.shape[0]  # 节点数
# 光伏的节点
PV_bus = PV_bus_define()
PV_p_forecast = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据
PV_capcity = 1.5**2  # 光伏的视在功率# 光伏并网后，节点负荷相应减少
penalty_cof = 1e-6 # 保证神经网络封闭性的惩罚系数
# 电压灵敏度矩阵：
# P_sensitivity_matrix = np.load('../data/sensitivity_matrix.npy')
# Q_sensitivity_matrix = np.load('../data/sensitivity_matrix.npy')
# 读取神经网络的参数
L = 2 # 隐藏层的层数
d = 30 # 每层神经元的数量
y_dim = len(PV_bus) # 模型参数的输入维度
constraint_dim = 2 * bus_num + len(PV_bus) # 联合机会约束中约束的数量
# 定义 CVXPY 变量
beita_cof = cp.Variable(len(PV_bus), name='control cof')  # 控制策略的斜率参数
obj_auxilary = cp.Variable(bus_num, name='obj_auxilary ')  # 目标函数线性化的辅助变量
"处理鲁棒约束所需要的变量"
niu_JCC = cp.Variable((constraint_dim, 2*L*d + 1), nonneg=True)  # 鲁棒约束的对偶变量,变量非负 +1 表示最后一层输出层 +2y_dim表示绝对值转化的约束
abs_niu_JCC = cp.Variable((constraint_dim, 2*y_dim), nonneg=True)  # 用于绝对值转化的变量
# 定义 CVXPY 参数
"PICNN的参数和不确定集合的size"
W_nu_stacked = cp.Parameter((L*d + 1, y_dim)) # passthrough路径的W  nu的最后一层参数置零用来保证紧凑性了
W_v_stacked = cp.Parameter(((L-1)*d + 1, d))  # 凸输入路径隐藏层的W  v的第一层输入置零了 
Ws = [W_v_stacked [d*l: d*(l+1)] for l in range(L)]
b_hidden = cp.Parameter((L, d)) # 隐藏层的偏置项
b_out = cp.Parameter() # 输出层的偏置项
size_tao = cp.Parameter()  # 不确定集合的尺寸参数
A_x_JCC = cp.Parameter((constraint_dim,len(PV_bus)), name='A_x')  # 鲁棒约束的变量仿射矩阵
B_x_JCC = cp.Parameter(constraint_dim,name='B_x')  # 鲁棒约束的常数系数
# 约束  基于PICNN不确定性集合的鲁棒约束转换
constr = []
for c in range(constraint_dim): # 对每一个约束进行统一化建模
    niu, abs_niu = niu_JCC[c], abs_niu_JCC[c]
    A_x, B_x = A_x_JCC[c], B_x_JCC[c]
    nius = [ niu[d*l: d*(l+1)] for l in range(2*L + 1)]
    "构建与不确定性变量有关的那一列约束，即凸输入变量的那一列对应的对偶约束"
    constr.append(W_nu_stacked.T @ niu[L*d:] + abs_niu[:y_dim] - abs_niu[y_dim:] == A_x) # 这里 -2*y_dim 表示排除最后两行对绝对值的转化约束对应的对偶变量
    constr.append(penalty_cof * niu[-1] == cp.sum(abs_niu))
    "构建与辅助变量有关的那一列约束"
    constr.append(W_nu_stacked.T @ niu[L*d:] - niu[-2*y_dim:-y_dim] - niu[-y_dim:] == 0) # 辅助变量那一列对应的对偶约束
    "与神经元变量相关的中间约束"
    for l in range(L):
        constr.append(Ws[l].T @ nius[L+l+1] - nius[l] - nius[L+l] == 0)  # 与神经元变量有关的对偶约束
    "用对偶项替换原来max项以后的约束:"
    dual_obj = 0
    for l in range(L):
        dual_obj += b_hidden[l] @ nius[L + l]
    dual_obj += (size_tao - b_out) * niu[-1] 
    constr.append(dual_obj <= B_x)

objective = cp.Minimize(cp.sum(obj_auxilary))
problem = cp.Problem(objective, constr)

assert problem.is_dcp(dpp=True)
layer = CvxpyLayer(problem, parameters=[W_nu_stacked,W_v_stacked,b_hidden,b_out,size_tao,A_x_JCC,B_x_JCC], variables=[beita_cof, obj_auxilary, niu_JCC, abs_niu_JCC])
# p_d_sol, p_c_sol, p_bid_sol, E_sol = layer(phi_torch, L_torch)