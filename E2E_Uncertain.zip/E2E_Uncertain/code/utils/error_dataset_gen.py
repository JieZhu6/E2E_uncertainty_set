import sys
import os
# 获取当前脚本的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取父目录 (即 utils 和 benchmark_method 的共同父目录)
parent_dir = os.path.dirname(current_dir)
# 将父目录添加到 sys.path 的开头
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

import numpy as np
from benchmark_method.system_initial import res_forecast_data,PV_bus_define

TEST_HOUR = 96  # 测试数据集的组数
PV_bus = PV_bus_define()
res_data,PV_capacity = res_forecast_data(TEST_HOUR,len(PV_bus))
test_size = 5000 # 测试集样本数
historical_size = 500 # 历史数据样本数
def Gassian_parameter(n):
    # 组数
    num_groups = TEST_HOUR
    # 初始化存储所有数据集的数组
    mean_set = np.zeros((TEST_HOUR,res_data.shape[1]))
    std_set = np.zeros((TEST_HOUR,res_data.shape[1]))
    for group in range(num_groups):
        # 生成 n 个 -0.1 到 0 的随机数作为均值
        mean = np.random.uniform(-0.1, 0.1, n)
        # 生成 n 个 0.45 到 0.6 的随机数作为标准差
        std = np.random.uniform(0.06, 0.07, n)
        mean_set[group] = mean
        std_set[group] = std
        # 计算方差
        var = std ** 2
        # 相关系数
        corr = 0.7
        # 构建协方差矩阵
        cov = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i == j:
                    cov[i, j] = var[i]  # 对角线是方差
                else:
                    cov[i, j] = corr * std[i] * std[j]  # 非对角线是协方差
    return mean_set,std_set

def res_error_data_generate(n):
    # 组数
    num_groups = TEST_HOUR
    mean_set,std_set = Gassian_parameter(n)
    # 初始化存储所有数据集的数组
    train_set = np.zeros((num_groups, historical_size, n))
    test_set = np.zeros((num_groups, test_size, n))
    for group in range(num_groups):
        mean = mean_set[group]
        std = std_set[group]
        # 计算方差
        var = std ** 2
        # 相关系数
        corr = 0.7
        # 构建协方差矩阵
        cov = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i == j:
                    cov[i, j] = var[i]  # 对角线是方差
                else:
                    cov[i, j] = corr * std[i] * std[j]  # 非对角线是协方差
        # 将生成的数据集存储到对应的组中
        train_set[group] = np.random.multivariate_normal(mean, cov, historical_size)
        test_set[group] = np.random.multivariate_normal(mean, cov, test_size)

    return train_set, test_set , mean_set,std_set

total_fit_data,total_test_data,mean_set,std_set = res_error_data_generate(len(PV_bus))

np.save('../training_dataset/total_fit_data.npy', total_fit_data[48])
np.save('../training_dataset/total_test_data.npy', total_test_data[48])