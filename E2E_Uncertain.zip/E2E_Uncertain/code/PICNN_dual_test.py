"""
检测一下对偶模型的代码写对没有
"""
import cvxpy as cp
from cvxpylayers.torch import CvxpyLayer
import numpy as np
import torch
from torch import nn, Tensor
from PICNN_model import PICNN

y_dim = 6  # Dimension of the output variable y
bus_num = 33  # Number of buses in the system
L = 2  # Number of hidden layers in the PICNN
d = 30  # Number of neurons in each hidden layer
epsilon = 1e-6  # Small constant for numerical stability
"PICNN的参数和不确定集合的size"
W_nu_stacked = np.ones((L*d + 1, y_dim)) # passthrough路径的W  nu的最后一层参数置零用来保证紧凑性了
W_v_stacked = np.ones(((L-1)*d + 1, d))  # 凸输入路径隐藏层的W  v的第一层输入置零了 
Ws = [W_v_stacked [d*l: d*(l+1)] for l in range(L)]
b_hidden = np.ones((L, d)) # 隐藏层的偏置项
b_out = 1 # 输出层的偏置项
size_tao = 100  # 不确定集合的尺寸参数
A_x_JCC = np.ones((y_dim))  # 鲁棒约束的变量仿射矩阵
y_max,y_min = 10,-10

def dual_problem():
    "处理鲁棒约束所需要的变量"
    niu_JCC = cp.Variable((2*L*d + 1), nonneg=True)  # 鲁棒约束的对偶变量,变量非负 +1 表示最后一层输出层 +2y_dim表示绝对值转化的约束
    abs_niu_JCC = cp.Variable(( 2*y_dim), nonneg=True)  # 用于绝对值转化的变量
    # 约束  基于PICNN不确定性集合的鲁棒约束转换
    constr = []
    niu, abs_niu, A_x  = niu_JCC, abs_niu_JCC, A_x_JCC
    nius = [ niu[d*l: d*(l+1)] for l in range(2*L + 1)]
    "构建与不确定性变量有关的那一列约束，即凸输入变量的那一列对应的对偶约束"
    constr.append(W_nu_stacked.T @ niu[L*d:] + abs_niu[:y_dim] - abs_niu[y_dim:] == A_x) # 这里 -2*y_dim 表示排除最后两行box不确定性集合
    "与神经元变量相关的中间约束"
    for l in range(L):
        constr.append(Ws[l].T @ nius[L+l+1] - nius[l] - nius[L+l] == 0)  # 与神经元变量有关的对偶约束
    "用对偶项替换原来max项以后的约束:"
    dual_obj = 0
    for l in range(L):
        dual_obj -= b_hidden[l] @ nius[L + l]
    for l in range(y_dim):
        dual_obj += abs_niu[l] * y_max - abs_niu[y_dim + l] * y_min
    dual_obj += (size_tao - b_out) * niu[-1] 
    pro = cp.Problem(cp.Minimize(dual_obj), constraints=constr)
    # 使用 Gurobi
    pro.solve(solver=cp.GUROBI, verbose=True)
    model = pro._solver_cache[cp.GUROBI]
    # model.computeIIS()  # ← 计算不可行子系统
    # model.write("infeasible.ilp")  # 输出矛盾约束
    print("The optimal value is", pro.value)

def primal_max():
    sigma = cp.Variable((L, d), nonneg=True)
    y = cp.Variable(y_dim, name='y')

    Vs = [W_nu_stacked[d*l: d*(l+1)] for l in range(L + 1)]
    Ws = [W_v_stacked[d*l: d*(l+1)] for l in range(L)]
    bs = b_hidden 
    b_fin = b_out

    constraints = []
    for l in range(L):
        if l == 0:
            constr = (sigma[l] >= Vs[0] @ y + bs[l])
        else:
            constr = (sigma[l] >= Ws[l-1] @ sigma[l-1] + Vs[l] @ y + bs[l])
        constraints.append(constr)
    constraints.append(y >= y_min)
    constraints.append(y <= y_max)
    constraints.append(Ws[L-1] @ sigma[L-1] + Vs[L] @ y + b_fin <= size_tao)
    obj = A_x_JCC @ y
    prob_primal_max = cp.Problem(cp.Maximize(obj), constraints=constraints)
    prob_primal_max.solve(solver=cp.GUROBI)
    print("The optimal value is", prob_primal_max.value)


dual_problem()
primal_max()


