import sys
import os
# 获取当前脚本的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取父目录 (即 utils 和 benchmark_method 的共同父目录)
parent_dir = os.path.dirname(current_dir)
# 将父目录添加到 sys.path 的开头
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
import numpy as np
import matplotlib.pyplot as plt
from gurobipy import Model,GRB,quicksum,MVar,concatenate
import numpy as np
from benchmark_method.system_initial import res_forecast_data,case33,forecast_load,PV_bus_define,Y_bus_matrix
from Matrix_sensitity import compute_voltage_sensitivity_distflow_linearized,validate_and_plot
from sklearn.preprocessing import MinMaxScaler
"定义系统常数"
plt.rcParams.update({'font.size': 16}) # 改变所有字体大小，改变其他性质类似
plt.rc('font',family='Times New Roman')
TEST_HOUR = 96 #仿真时长
#电价、负荷数据
SYSTEM_DATA = case33()
ACTIVE_LOAD_base,REACTIVE_LOAD_base = np.array(forecast_load(TEST_HOUR)) # 转化为标幺值
R_ij_matrix,X_ij_matrix = Y_bus_matrix() #节点导纳矩阵
#网络拓普数据
branch = np.array(SYSTEM_DATA['branch'])
bus = np.array(SYSTEM_DATA['bus'])
V_MAX,V_MIN,branch_max = 1.05,0.95,100
# 光伏的节点
PV_bus = PV_bus_define()
PV_p_forecast_base,PV_capcity = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据
"迭代生成潮流数据用于生成电压灵敏度矩阵"
point_num = 20 # 生成数据点数量
time_intervel = range(4*11,4*13) # 选取11点到下午1点的数据进行训练
dV_dP,dV_dQ,PV_p,Phoval_Q = [],[],[],[]  # 用于存储数据
for q in range(point_num):
    ACTIVE_LOAD = ACTIVE_LOAD_base * np.random.uniform(0.9, 1.1, size=ACTIVE_LOAD_base.shape)
    REACTIVE_LOAD = REACTIVE_LOAD_base * np.random.uniform(0.9, 1.1, size=REACTIVE_LOAD_base.shape)
    PV_p_forecast = PV_p_forecast_base * np.random.uniform(0.9, 1.1, size=PV_p_forecast_base.shape)
    # VVC优化模型
    model = Model('')
    '光伏无功的可控范围'
    pv_Q = model.addMVar((TEST_HOUR,len(PV_bus)),lb = -GRB.INFINITY,vtype = GRB.CONTINUOUS, name = 'PV_Q_power')
    model.addConstr(pv_Q**2 + PV_p_forecast**2 <= PV_capcity**2 )
    '平衡节点的有功和无功'
    MG_Power = model.addMVar((TEST_HOUR,2),lb = 0,ub = GRB.INFINITY,vtype = GRB.CONTINUOUS, name = 'MG_power')  
    """定义二阶锥潮流约束"""
    branch_current = model.addMVar((TEST_HOUR,branch.shape[0]),lb = -1*branch_max,ub = branch_max,vtype = GRB.CONTINUOUS, name=f'branch_current')
    P_ij = model.addMVar((TEST_HOUR,branch.shape[0]),lb = -1*branch_max,ub = branch_max,vtype = GRB.CONTINUOUS, name=f'P_ij')
    Q_ij = model.addMVar((TEST_HOUR,branch.shape[0]),lb = -1*branch_max,ub = branch_max,vtype = GRB.CONTINUOUS, name=f'Q_ij')
    power_loss = model.addMVar((TEST_HOUR,branch.shape[0]),lb = -1*branch_max,ub = branch_max,vtype = GRB.CONTINUOUS, name=f'power_loss') # 记录下有功网损
    """节点的电压以及节点注入功率"""
    Bus_V = model.addMVar((TEST_HOUR,bus.shape[0]),lb = V_MIN**2,ub = V_MAX**2,vtype = GRB.CONTINUOUS, name = 'Bus_V')  # 节点电压的平方
    Bus_P_inj = model.addMVar((TEST_HOUR,bus.shape[0]),lb = -GRB.INFINITY,ub = GRB.INFINITY,vtype = GRB.CONTINUOUS, name = 'Bus_P_inj')
    Bus_Q_inj = model.addMVar((TEST_HOUR,bus.shape[0]),lb = -GRB.INFINITY,ub = GRB.INFINITY,vtype = GRB.CONTINUOUS, name = 'Bus_P_inj')
    """平衡节点 以1节点为参考节点"""
    # 平衡节点的OLTC运行约束
    delta = model.addMVar(TEST_HOUR, vtype=GRB.INTEGER, lb = -2, ub = 2, name="delta")   # 分接头档位
    u = model.addMVar(TEST_HOUR, vtype=GRB.CONTINUOUS, lb=0, name="u")  # 辅助变量 |delta_t - delta_{t-1}|
    max_single_step,max_total_step,Vtap = 2,1,0.01  # 最大单步变动
    model.addConstr(delta[0] == 0)  # 初始档位为0
    for t in range(TEST_HOUR):
        if t > 1:
            # 线性化绝对值
            model.addConstr(u[t] >= delta[t] - delta[t-1])
            model.addConstr(u[t] >= delta[t-1] - delta[t])
            # 每步动作限制
            model.addConstr(u[t] <= max_single_step)
    # 总操作次数约束
    model.addConstr(u.sum() <= max_total_step)
    # 电压关系
    model.addConstr(Bus_V[:,0] == (np.ones(TEST_HOUR) + delta*Vtap)**2)
    # model.addConstr(Bus_V[:,0] == np.ones(TEST_HOUR))
    "二阶锥松弛的distflow潮流传输约束"
    """支路功率和节点注入电压的约束"""
    for i in range(bus.shape[0]):
        # 父节点和子节点的索引
        upper_index,lower_index = np.int16(branch[np.where(branch[:, 1] == i+1)[0],0]-1),np.int16(branch[np.where(branch[:, 0] == i+1)[0],1]-1)
        # 流入支路和流出支路的索引
        upper_branch_indices,lower_branch_indices = [],[]
        for j in upper_index: # 节点i作为支路末端节点
            branch_indices = np.where((branch[:,0].astype(int) == j+1) & (branch[:,1].astype(int) == i+1))[0] # 检索支路索引
            if len(branch_indices) != 0:
                upper_branch_indices.append(branch_indices[0])  # 记录上游支路
        for j in lower_index: # 节点i作为支路末端节点
            branch_indices = np.where((branch[:,0].astype(int) == i+1) & (branch[:,1].astype(int) == j+1))[0] # 检索支路索引
            if len(branch_indices) != 0:
                lower_branch_indices.append(branch_indices[0])  # 记录下游支路            
        "计算有功功率"
        upper_flow_power,lower_flow_power = 0,0
        if len(upper_index) != 0: # 有上游节点的情况，主要是排除首节点        
            upper_flow_power += P_ij[:,upper_branch_indices].sum(axis = 1)
            for j in range(len(upper_index)):
                upper_flow_power -= R_ij_matrix[i,upper_index[j]] * branch_current[:,upper_branch_indices[j]] # 减去线路损耗
                model.addConstr(power_loss[:,upper_branch_indices[j]] == R_ij_matrix[i,upper_index[j]] * branch_current[:,upper_branch_indices[j]]) # 记录有功网损
        if len(lower_index) != 0: # 有下游节点的情况，主要是排除末端节点
            lower_flow_power += P_ij[:,lower_branch_indices].sum(axis = 1)
        model.addConstr(Bus_P_inj[:,i] == lower_flow_power - upper_flow_power) # 节点注入功率等于流出的 - 上一节点流出的 - 线路的损耗
        "计算无功功率"
        upper_flow_power,lower_flow_power = 0,0
        if len(upper_index) != 0: # 有上游节点的情况，主要是排除首节点        
            upper_flow_power += Q_ij[:,upper_branch_indices].sum(axis = 1)
            for j in range(len(upper_index)):
                upper_flow_power -= X_ij_matrix[i,upper_index[j]] * branch_current[:,upper_branch_indices[j]] # 减去线路损耗
        if len(lower_index) != 0: # 有下游节点的情况，主要是排除末端节点
            lower_flow_power += Q_ij[:,lower_branch_indices].sum(axis = 1)
        model.addConstr(Bus_Q_inj[:,i] == lower_flow_power - upper_flow_power) # 节点注入功率等于流出的 - 上一节点流出的 - 线路的损耗
    """电压降落约束，以及二阶锥松弛约束,以及转换开关的约束"""
    for i in range(bus.shape[0]):
        # 这里电压降落只用考虑子节点就好
        lower_index = np.int16(branch[np.where(branch[:, 0] == i+1)[0],1]-1)
        # 流出支路的索引
        lower_branch_indices = []
        for j in lower_index: # 节点i作为支路末端节点
            branch_indices = np.where((branch[:,0].astype(int) == i+1) & (branch[:,1].astype(int) == j+1))[0] # 检索支路索引
            if len(branch_indices) != 0:
                lower_branch_indices.append(branch_indices[0])  # 记录下游支路   
        for j in range(len(lower_index)):
            # print(R_ij_matrix[i,lower_index[j]])
            drop_part1 = 2*(R_ij_matrix[i,lower_index[j]]*P_ij[:,lower_branch_indices[j]] + X_ij_matrix[i,lower_index[j]]*Q_ij[:,lower_branch_indices[j]])
            drop_part2 = (R_ij_matrix[i,lower_index[j]]**2 + X_ij_matrix[i,lower_index[j]]**2)*branch_current[:,lower_branch_indices[j]] # 网损项
            model.addConstr(Bus_V[:,lower_index[j]] == Bus_V[:,i] - drop_part1 + drop_part2)
            """支路电流、电压和有功潮流、无功潮流的平方的二阶锥松弛"""
            model.addConstr(branch_current[:,lower_branch_indices[j]] * Bus_V[:,i] >= (P_ij[:,lower_branch_indices[j]]**2 + Q_ij[:,lower_branch_indices[j]]**2))
    "节点注入功率平衡约束"
    count_PV = 0
    for i in range(bus.shape[0]):
        if i == 0:
            model.addConstr(Bus_P_inj[:,i] == MG_Power[:,0] - ACTIVE_LOAD[i,:])
            model.addConstr(Bus_Q_inj[:,i] == MG_Power[:,1] - REACTIVE_LOAD[i,:])
        elif np.isin(i+1,PV_bus): # PV连接节点
            model.addConstr(Bus_P_inj[:,i] == PV_p_forecast[:,count_PV] - ACTIVE_LOAD[i,:])
            model.addConstr(Bus_Q_inj[:,i] == pv_Q [:,count_PV] - REACTIVE_LOAD[i,:])
            count_PV += 1
        else:
            model.addConstr(Bus_P_inj[:,i] == - ACTIVE_LOAD[i,:])
            model.addConstr(Bus_Q_inj[:,i] == - REACTIVE_LOAD[i,:])

    # 目标函数最小化网损
    obj = power_loss.sum()
    model.setObjective(obj,GRB.MINIMIZE)  #除了原上层模型目标函数其余皆为负号
    model.setParam('MIPGap',0.01)
    model.Params.OutputFlag = 0
    model.setObjective(obj,GRB.MINIMIZE)  #除了原上层模型目标函数其余皆为负号
    model.optimize()
    if model.status != GRB.OPTIMAL:
        print(f"Warning: Iteration {q}: Optimization was not successful. Status: {model.status}")
        # 可以选择打印更详细的状态信息
        # print(f"Status: {model.Status}")
        continue  # 跳过本次循环的剩余代码，进入下一次迭代 (j+1)
    # --- 只有当求解成功 (OPTIMAL) 时才会执行的代码 ---
    print(f"Iteration {q}: Optimization successful. Objective value: {model.objVal}")
    branch_template = branch[:,:4]
    # 只选取有光伏出力时候的时间生成数据
    for t in time_intervel:
        # 计算灵敏度矩阵
        dVdp,dVdq = compute_voltage_sensitivity_distflow_linearized(branch_template,bus.shape[0],P_ij.X[t,:],Q_ij.X[t,:],branch_current.X[t,:],Bus_V.X[t,:])
        # 储存数据
        dV_dP.append(dVdp)
        dV_dQ.append(dVdq)
        PV_p.append(PV_p_forecast[t,:])
        Phoval_Q.append(pv_Q.X[t,:])
        # # 验证灵敏度矩阵的正确性
        # 2. 设置扰动 (随机扰动测试)
        # delta_P = np.zeros(bus.shape[0])
        # delta_Q = np.zeros(bus.shape[0])
        # delta_P[PV_bus-1] = -0.05
        # delta_Q[PV_bus-1] = 0
        # P_inj, Q_inj = Bus_P_inj.X[t,:], Bus_Q_inj.X[t,:]
        # P_inj, Q_inj = P_inj - delta_P, Q_inj - delta_Q # 注意注入功率的符号
        # 3. 验证 & 绘图
        # predicted_V, actual_V, error = validate_and_plot(dVdp, dVdq, Bus_V.X[t,:], delta_P, delta_Q, -P_inj, -Q_inj ,branch_template, bus.shape[0])
dV_dP = np.array(dV_dP).reshape(-1,bus.shape[0],bus.shape[0])
dV_dQ = np.array(dV_dQ).reshape(-1,bus.shape[0],bus.shape[0])
PV_p,Phoval_Q = np.array(PV_p),np.array(Phoval_Q)
# 选出与PV节点相关的灵敏度矩阵，并进行池化操作
dV_dP_PV = -1*dV_dP[:,PV_bus-1,1:]  # 选出与PV节点相关的灵敏度矩阵
dV_dQ_PV = -1*dV_dQ[:,PV_bus-1,1:]  # 符号与PV出力对应
def pool_and_flatten(arr, operations=('max', 'min', 'mean'), axis=-1):
    """
    对数组的指定轴进行池化操作（如最大值、最小值、平均值），然后展平为二维数组。
    
    参数:
    -----------
    arr : numpy.ndarray
        输入的多维数组，例如形状为 (280, 6, 33)
    operations : tuple of str
        要应用的聚合操作，可选 'max', 'min', 'mean', 'std', 'sum' 等
    axis : int
        要进行池化操作的轴，默认为最后一维 (-1)
    
    返回:
    --------
    numpy.ndarray
        形状为 (N, M * len(operations)) 的二维数组
    
    示例:
    --------
    >>> data = np.random.rand(280, 6, 33)
    >>> result = pool_and_flatten(data)
    >>> print(result.shape)  # (280, 18)
    """
    # 支持的操作映射
    op_map = {
        'max': np.max,
        'min': np.min,
        'mean': np.mean,
        'std': np.std,
        'sum': np.sum
    }
    
    # 输入验证
    if not isinstance(arr, np.ndarray):
        raise TypeError("输入必须是 numpy.ndarray")
    
    if axis >= arr.ndim or axis < -arr.ndim:
        raise ValueError(f"axis {axis} 超出数组维度范围 {arr.ndim}")
    
    # 存储每个操作的结果
    pooled_results = []
    
    for op in operations:
        if op not in op_map:
            raise ValueError(f"不支持的操作: {op}，支持的操作: {list(op_map.keys())}")
        
        # 应用聚合函数
        result = op_map[op](arr, axis=axis)
        pooled_results.append(result)
    
    # 沿最后一个轴（特征轴）拼接结果
    # 假设原始 shape 为 (N, M, ...), 池化后每个为 (N, M)
    # 拼接后为 (N, M * num_ops)
    if len(pooled_results) == 1:
        concatenated = pooled_results[0]
    else:
        concatenated = np.concatenate(pooled_results, axis=1)
    
    return concatenated
pooled_dV_dP = pool_and_flatten(dV_dP_PV)
pooled_dV_dQ = pool_and_flatten(dV_dQ_PV)
mask_uncertainty = np.ones((pooled_dV_dP.shape[0], len(PV_bus)))
# 把没有pooled的光伏数据的第二维度和三维度展开
dV_dP_PV = dV_dP_PV.reshape(dV_dP_PV.shape[0],-1)
dV_dQ_PV = dV_dQ_PV.reshape(dV_dQ_PV.shape[0],-1)
pooled_y = np.concatenate((pooled_dV_dP,pooled_dV_dQ,PV_p,Phoval_Q),axis = 1) # 归一化的池化后的协变量信息
scaler = MinMaxScaler() 
pooled_y_normalized = scaler.fit_transform(pooled_y)
initial_y = np.concatenate((dV_dP_PV,dV_dQ_PV,PV_p,Phoval_Q),axis = 1)
train_dataset = np.concatenate((mask_uncertainty,pooled_y_normalized,initial_y),axis = 1) # 拼接成最终的训练数据
# 储存
os.makedirs('../data', exist_ok=True)
np.save('../training_dataset/train_dataset.npy', train_dataset)