"""
定义基于PICNN不确定性集合的通用优化模型
This module implements optimization over PICNN sublevel set uncertainty.
"""
import cvxpy as cp
from cvxpylayers.torch import CvxpyLayer
import numpy as np
import torch
from torch import nn, Tensor
from PICNN_model import PICNN
from protocols import PICNNProblemProtocol
import os
from benchmark_method.system_initial import res_forecast_data,PV_bus_define
torch.set_printoptions(precision=10, sci_mode=False)
TEST_HOUR = 96
PV_bus = PV_bus_define()
PV_p_forecast,PV_capcity = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据

def einsum_batch_diag(A: Tensor, B: Tensor) -> Tensor:
    """
    Computes A @ batch_diag(B) using einsum.

    Equivalent to
        torch.stack([
            A @ torch.diag(B[i]) for i in range(B.shape[0])
        ])

    Args:
        A: shape (m, n)
        B: shape (batch_size, n)

    Returns:
        result: shape (batch_size, m, n)
    """
    # einsum expression explanation:
    # 'ik,kj->ij' represents the matrix multiplication of A and diag(B_i)
    return torch.einsum('ij,bj->bij', A, B)


class PICNNProblem:
    """
    Args:
        constraint_dim: number of constraints in the JCC
        u_dim: dimension of uncertain input
        L: # of hidden layers in PICNN
        bus_num: number of buses in the system
        d: dimension of the hidden layers in PICNN
        epsilon: weight for ‖y‖∞ term in output layer of PICNN
    """
    def __init__(self, u_dim: int, bus_num : int, L: int, d: int, epsilon: float = 0.):
        self.u_dim = u_dim
        self.bus_num = bus_num
        self.epsilon = epsilon
        self.L = L
        self.d = d
        constraint_dim = 2*(bus_num-1) + u_dim*4  # 约束的数量除了松弛节点外的电压偏移量 + 光伏逆变器的容量约束 （默认功率会大于0）
        "目标函数线性化的辅助变量"
        obj_auxilary = cp.Variable(bus_num - 1, name='obj_auxilary', nonneg=True)  # 目标函数线性化的辅助变量
        "处理鲁棒约束所需要的变量"
        niu_JCC = cp.Variable((constraint_dim, 2*L*d + 1), name='JCC dual variable', nonneg=True)  # 鲁棒约束的对偶变量,变量非负 +1 表示最后一层输出层 +2y_dim表示绝对值转化的约束
        Box_niu_JCC = cp.Variable((constraint_dim, 2*u_dim),name='Box auxilary variable', nonneg=True)  # 用于绝对值转化的变量
        "控制策略的参数"
        beita_cof =  cp.Variable(u_dim, name='control policy parameter')
        # 定义 CVXPY 参数
        "PICNN的参数和不确定集合的size"
        W_nu_stacked = cp.Parameter((L*d + 1, u_dim), name='W_nu_stacked') # passthrough路径的W 
        W_v_stacked = cp.Parameter(((L-1)*d + 1, d), name='W_v_stacked')  # 凸输入路径隐藏层的W  v的第一层输入置零了 
        Ws = [W_v_stacked [d*l: d*(l+1)] for l in range(L)]
        b_hidden = cp.Parameter((L, d), name='b_hidden') # 隐藏层的偏置项
        b_out = cp.Parameter(name='b_out') # 输出层的偏置项
        size_tao = cp.Parameter(name='size_tao')  # 不确定集合的尺寸参数
        Voltage_sensitity = cp.Parameter((u_dim,2*(bus_num-1)), name='Voltage_sensitity')  # 光伏节点对于其他非松弛节点的电压灵敏度
        day_ahead_P_Q = cp.Parameter((u_dim*2), name='day_ahead_P_Q')  # 光伏日前确定的功率 有功在前 无功在后
        error_max = cp.Parameter((u_dim), name='error_max')
        error_min = cp.Parameter((u_dim), name='error_min')
        self.params = {
            'W_nu_stacked': W_nu_stacked,
            'Voltage_sensitity': Voltage_sensitity,
            'W_v_stacked': W_v_stacked,
            'b_hidden': b_hidden,
            'error_max': error_max,
            'error_min': error_min,
            'b_out': b_out,
            'size_tao': size_tao,
            'day_ahead_P_Q': day_ahead_P_Q,
        }
        self.dual_vars = {
            'obj_auxilary': obj_auxilary,
            'niu_JCC': niu_JCC,
            'Box_niu_JCC': Box_niu_JCC,
            'beita_cof': beita_cof,
        }
        constr = []
        # 约束  基于PICNN不确定性集合的鲁棒约束转换
        for c in range(constraint_dim):
            niu = niu_JCC[c]        # shape: (2Ld + 1,)
            Box_niu = Box_niu_JCC[c] # shape: (2u_dim,)

            # --- 构造 A_x: 使用列表收集表达式 ---
            A_x_list = []
            B_x = None

            if c < bus_num - 1:  # 电压约束 1
                for j in range(u_dim):
                    expr = Voltage_sensitity[j, c] + Voltage_sensitity[j, c + bus_num - 1] * beita_cof[j]
                    A_x_list.append(expr)
                B_x = obj_auxilary[c]

            elif c < 2*(bus_num - 1):  # 电压约束 2
                idx = c - (bus_num - 1)
                for j in range(u_dim):
                    expr = -(Voltage_sensitity[j, idx] + Voltage_sensitity[j, idx + bus_num - 1] * beita_cof[j])
                    A_x_list.append(expr)
                B_x = obj_auxilary[idx]

            else:
                # 提取光伏索引
                pv_idx = (c - 2*(bus_num - 1))
                P_hat = day_ahead_P_Q[pv_idx%u_dim]
                Q_hat = day_ahead_P_Q[pv_idx%u_dim + u_dim]

                if pv_idx < u_dim:  # 容量约束 1: (√2-1)P + Q ≤ S
                    J_P, J_Q = np.sqrt(2) - 1, 1
                    for j in range(u_dim):
                        if j == pv_idx:
                            A_x_list.append(np.sqrt(2) - 1 + 1 * beita_cof[j])
                        else:
                            A_x_list.append(0.0)
                    B_x = PV_capcity - J_P * P_hat - J_Q  * Q_hat

                elif pv_idx < 2*u_dim:  # 容量约束 2: P + (√2-1)Q ≤ S
                    J_P, J_Q = 1, np.sqrt(2) - 1
                    pv_idx -= u_dim
                    for j in range(u_dim):
                        if j == pv_idx:
                            A_x_list.append(J_P + J_Q * beita_cof[j])
                        else:
                            A_x_list.append(0.0)
                    B_x = PV_capcity - J_P * P_hat - J_Q  * Q_hat

                elif pv_idx < 3*u_dim:  # 有功下限: -(P + (1-√2)Q) ≤ S
                    J_P, J_Q = 1, 1 - np.sqrt(2)
                    pv_idx -= 2*u_dim
                    for j in range(u_dim):
                        if j == pv_idx:
                            A_x_list.append(J_P + J_Q * beita_cof[j])
                        else:
                            A_x_list.append(0.0)
                    B_x = PV_capcity - J_P * P_hat - J_Q  * Q_hat

                elif pv_idx < 4*u_dim:  # 无功下限: -((√2-1)P - Q) ≤ S
                    J_P, J_Q = np.sqrt(2) - 1, -1
                    pv_idx -= 3*u_dim
                    for j in range(u_dim):
                        if j == pv_idx:
                            A_x_list.append(J_P + J_Q * beita_cof[j])
                        else:
                            A_x_list.append(0.0)
                    B_x = PV_capcity - J_P * P_hat - J_Q  * Q_hat

            # 将 A_x_list 转为 CVXPY 向量
            A_x = cp.hstack(A_x_list)

            nius = [ niu[d*l: d*(l+1)] for l in range(2*L + 1)]
            "构建与不确定性变量有关的那一列约束，即凸输入变量的那一列对应的对偶约束"
            constr.append(W_nu_stacked.T @ niu[L*d:] + Box_niu[:u_dim] - Box_niu[u_dim:] == A_x) # 这里 -2*y_dim 表示排除最后两行对绝对值的转化约束对应的对偶变量
            "与神经元变量相关的中间约束"
            for l in range(L):
                constr.append(Ws[l].T @ nius[L+l+1] - nius[l] - nius[L+l] == 0)  # 与神经元变量有关的对偶约束
            "用对偶项替换原来max项以后的约束:"
            dual_obj = 0
            for l in range(L):
                dual_obj -= b_hidden[l] @ nius[L + l]
            for l in range(u_dim):
                dual_obj += Box_niu[l] * error_max[l] - Box_niu[u_dim + l] * error_min[l]
            dual_obj += (size_tao - b_out) * niu[-1] 
            constr.append(dual_obj <= B_x)

        obj = cp.sum(obj_auxilary)
        self.dual_obj = obj
        # obj = cp.sum_squares(obj_auxilary + 1)
        self.dual_constraints = constr
        prob = cp.Problem(cp.Minimize(obj), self.dual_constraints)
        print('Is DPP:', prob.is_dpp())
        assert prob.is_dpp()
        self.prob = prob

    def solve_cvxpylayers(self, y: Tensor,initial_y: Tensor, model: PICNN, size_tao: Tensor, layer: CvxpyLayer) -> list[Tensor]:
        assert model.L == self.L
        assert model.hidden_dim == self.d
        assert model.epsilon == self.epsilon
        # y是非凸输入的协变量信息 initial_y 是灵敏度矩阵没有池化的时候
        ReLU = nn.ReLU()
        L = model.L
        d = model.hidden_dim
        batch_size = y.shape[0]
        V_stacked = torch.zeros((batch_size, L*d + 1, model.u_dim))
        Vs = [
            V_stacked[:, d*l: d*(l+1)] for l in range(L + 1)
        ]
        W_stacked = torch.zeros((batch_size, (L-1)*d + 1, d))
        Ws = [
            W_stacked[:, d*l: d*(l+1)] for l in range(L)
        ]
        bs = torch.zeros((batch_size, L, d))

        u = y
        for l in range(L):
            if l > 0:
                W_hat_vec = ReLU(model.W_hat_layers[l](u))
                Ws[l-1][:] = einsum_batch_diag(model.W_bar_layers[l].weight, W_hat_vec)
            V_hat_vec = model.V_hat_layers[l](u)
            Vs[l][:] = einsum_batch_diag(model.V_bar_layers[l].weight, V_hat_vec)
            bs[:, l] = model.b_layers[l](u)
            u = ReLU(model.u_layers[l](u))
        l = L
        W_hat_vec = ReLU(model.W_hat_layers[l](u))
        Ws[l-1][:] = einsum_batch_diag(model.W_bar_layers[l].weight, W_hat_vec)
        V_hat_vec = model.V_hat_layers[l](u)
        Vs[l][:] = einsum_batch_diag(model.V_bar_layers[l].weight, V_hat_vec)
        b_fin = model.b_layers[l](u)[:, 0]

        # 上面是带入神经网络参数 下面是对问题参数带入
        # print(initial_y.shape)
        Voltage_sensitity = initial_y[:,:-2*self.u_dim].reshape(initial_y.shape[0],self.u_dim,2*(self.bus_num-1))
        day_ahead_P_Q = initial_y[:,-2*self.u_dim:]
        # 计算不确定性变量的最大最小值
        os.makedirs('../data', exist_ok=True)
        error_dataset = np.load('../training_dataset/total_fit_data.npy')
        error_nominal = np.zeros((b_fin.shape[0],error_dataset.shape[0],error_dataset.shape[1]))
        # print(error_nominal.shape)
        # 把误差百分比转化为实际值
        for i in range(error_dataset.shape[0]):
            error_nominal[:,i,:] = day_ahead_P_Q[:,:self.u_dim].detach().numpy()*error_dataset[i]
        error_max,error_min =  np.max(error_nominal, axis=1),np.min(error_nominal, axis=1)
        # 转化回tensor
        error_max,error_min = torch.from_numpy(error_max).float().to('cpu', non_blocking=True),torch.from_numpy(error_min).float().to('cpu', non_blocking=True)
        # print(V_stacked.shape,  Voltage_sensitity.shape, W_stacked.shape, bs.shape, size_tao.shape,b_fin.shape,day_ahead_P_Q.shape)
        # 检测模型不可行的原因
        idx = 0  # 调试第一个样本
        # # # 绑定参数值（同前）
        self.params['W_nu_stacked'].value = V_stacked[idx].detach().numpy()
        self.params['W_v_stacked'].value = W_stacked[idx].detach().numpy()
        self.params['b_hidden'].value = bs[idx].detach().numpy()
        self.params['b_out'].value = b_fin[idx].detach().numpy().item()
        self.params['size_tao'].value = size_tao[idx].detach().numpy().item()
        self.params['Voltage_sensitity'].value = Voltage_sensitity[idx].detach().numpy()
        self.params['day_ahead_P_Q'].value = day_ahead_P_Q[idx].detach().numpy()
        self.params['error_max'].value = error_max[idx].detach().numpy()
        self.params['error_min'].value = error_min[idx].detach().numpy()
        # # 导出lp文件检测哪里不可行
        # # 调用 Gurobi，并使用回调导出
        # self.prob.solve(solver=cp.GUROBI, verbose=False, reoptimize=True)
        self.prob.solve(solver=cp.GUROBI, verbose=False)
        model = self.prob._solver_cache[cp.GUROBI]
        print(f'gurobi_opt_value:{model.ObjVal:.6f}','gurobi_optimal_variable:',self.dual_vars['beita_cof'].value)
        # if model.status != 2:
        #     model.computeIIS()  # ← 计算不可行子系统
        model.write("model.lp")
        #     model.write("model.ilp")  # 输出矛盾约束
        # solution = layer(V_stacked, Voltage_sensitity, W_stacked, bs, error_max,error_min, size_tao, b_fin, day_ahead_P_Q,
        #                  solver_args={"solve_method": "ECOS","verbose": False,# 是否打印日志
        #                     "abstol": 1e-9,          # 绝对误差容忍度
        #                     "reltol": 1e-9,          # 相对误差容忍度
        #                     "feastol": 1e-9,         # 可行性容忍度
        #                     "max_iters": 10000,
        #                 })
        # solution = layer(V_stacked, Voltage_sensitity, W_stacked, bs, error_max,error_min, size_tao, b_fin, day_ahead_P_Q,solver_args={"eps": 1e-8, "max_iters": 10000, "acceleration_lookback": 0})
        solution = layer(V_stacked, Voltage_sensitity, W_stacked, bs, error_max,error_min, size_tao, b_fin, day_ahead_P_Q,solver_args={ "solve_method": "Clarabel"})
        print(f'cvxpylayers_opt_value:{sum(torch.sum(x) for x in solution[0]) }',f'cvxpylayers_optimal_variable:{solution[3][0].detach().numpy()}')
        # print(f'cvxpylayers_opt_value:{sum(torch.sum((x+1)**2) for x in solution[0]) }',f'cvxpylayers_optimal_variable:{solution[3][0].detach().numpy()}')
        # solution = layer(V_stacked, Voltage_sensitity, W_stacked, bs, error_max,error_min, size_tao, b_fin, day_ahead_P_Q, solver_args={"verbose": True,"eps": 1e-10, "max_iters": 20000, "acceleration_lookback": 0})
        return solution


    def solve_solver(self, y: Tensor, initial_y: Tensor, model: PICNN, size_tao: Tensor) -> list[Tensor]:
        """
        支持 batch 输入，但内部循环逐样本求解（因为原生 CVXPY 不支持 batch）
        返回：每个变量的 batch 解 [Tensor(batch, ...), ...]
        """
        assert model.L == self.L
        assert model.hidden_dim == self.d
        assert model.epsilon == self.epsilon

        ReLU = nn.ReLU()
        L = model.L
        d = model.hidden_dim
        batch_size = y.shape[0]

        # ========== 构造 PICNN 参数（完全不变） ==========
        V_stacked = torch.zeros((batch_size, L*d + 1, model.u_dim))
        Vs = [V_stacked[:, d*l: d*(l+1)] for l in range(L + 1)]
        W_stacked = torch.zeros((batch_size, (L-1)*d + 1, d))
        Ws = [W_stacked[:, d*l: d*(l+1)] for l in range(L)]
        bs = torch.zeros((batch_size, L, d))

        u = y
        for l in range(L):
            if l > 0:
                W_hat_vec = ReLU(model.W_hat_layers[l](u))
                Ws[l-1][:] = einsum_batch_diag(model.W_bar_layers[l].weight, W_hat_vec)
            V_hat_vec = model.V_hat_layers[l](u)
            Vs[l][:] = einsum_batch_diag(model.V_bar_layers[l].weight, V_hat_vec)
            bs[:, l] = model.b_layers[l](u)
            u = ReLU(model.u_layers[l](u))
        l = L
        W_hat_vec = ReLU(model.W_hat_layers[l](u))
        Ws[l-1][:] = einsum_batch_diag(model.W_bar_layers[l].weight, W_hat_vec)
        V_hat_vec = model.V_hat_layers[l](u)
        Vs[l][:] = einsum_batch_diag(model.V_bar_layers[l].weight, V_hat_vec)
        b_fin = model.b_layers[l](u)[:, 0]

        Voltage_sensitity = initial_y[:,:-2*self.u_dim].reshape(initial_y.shape[0], self.u_dim, 2*(self.bus_num-1))
        day_ahead_P_Q = initial_y[:,-2*self.u_dim:]

        os.makedirs('../data', exist_ok=True)
        error_dataset = np.load('../training_dataset/total_fit_data.npy')
        error_nominal = np.zeros((b_fin.shape[0], error_dataset.shape[0], error_dataset.shape[1]))
        for i in range(error_dataset.shape[0]):
            error_nominal[:,i,:] = day_ahead_P_Q[:,:self.u_dim].detach().numpy() * error_dataset[i]
        error_max_np, error_min_np = np.max(error_nominal, axis=1), np.min(error_nominal, axis=1)
        error_max = torch.from_numpy(error_max_np).float().to('cpu', non_blocking=True)
        error_min = torch.from_numpy(error_min_np).float().to('cpu', non_blocking=True)
        # ========== 构造结束 ==========

        # ✅ 参数映射（注意：这里 tensor_value 是 batch 的）
        param_mapping = [
            ('W_nu_stacked', V_stacked),          # shape: (B, L*d+1, u_dim)
            ('Voltage_sensitity', Voltage_sensitity),  # (B, u_dim, 2*(bus-1))
            ('W_v_stacked', W_stacked),           # (B, (L-1)*d+1, d)
            ('b_hidden', bs),                     # (B, L, d)
            ('error_max', error_max),             # (B, u_dim)
            ('error_min', error_min),             # (B, u_dim)
            ('size_tao', size_tao),               # scalar or (B,)
            ('b_out', b_fin),                     # (B,)
            ('day_ahead_P_Q', day_ahead_P_Q),     # (B, 2*u_dim)
        ]

        # 📦 存储每个样本的解
        solutions_batch = {
            'obj_auxilary': [],
            'niu_JCC': [],
            'Box_niu_JCC': [],
            'beita_cof': [],
        }

        # 🔁 循环处理每个样本
        for i in range(batch_size):
            print(f"\n🧩 求解样本 {i+1}/{batch_size}")

            # 赋值（去掉 batch 维度）
            for param_name, tensor_value in param_mapping:
                param = self.params[param_name]
                value_np = tensor_value[i].detach().cpu().numpy()  # 取第 i 个样本
                param.value = value_np

            # 🚀 求解
            try:
                self.prob.solve(solver=cp.GUROBI, verbose=True)  # 关闭 verbose 避免刷屏
            except Exception as e:
                print(f"⚠️ GUROBI 失败，降级 SCS: {str(e)}")
                self.prob.solve(solver=cp.SCS, verbose=False, eps=1e-5, max_iters=10000)

            if self.prob.status not in [cp.OPTIMAL, cp.OPTIMAL_INACCURATE]:
                print(f"❌ 样本 {i} 求解失败，状态: {self.prob.status}")
                return None

            # 提取解
            for var_name in solutions_batch.keys():
                var = self.dual_vars[var_name]
                if var.value is None:
                    print(f"⚠️ 样本 {i}: {var_name} 无解")
                    return None
                solutions_batch[var_name].append(torch.tensor(var.value, dtype=torch.float32))

        # 📦 合并为 batch tensor
        final_solutions = []
        for var_name in ['obj_auxilary', 'niu_JCC', 'Box_niu_JCC', 'beita_cof']:
            # 所有样本的解堆叠起来
            stacked = torch.stack(solutions_batch[var_name], dim=0)  # (batch, ...)
            final_solutions.append(stacked)

        return final_solutions
    
def cal_q(model: PICNN, y, alpha: float, device: str = 'cpu') -> Tensor:
    """
    Args:
        model: model to evaluate
        alpha: desired coverage level in (0, 1)
        device: device to use

    Returns:
        q: scalar score threshold for the desired coverage level
    """
    model.to(device)
    all_q = []
    os.makedirs('../data', exist_ok=True)
    error_dataset = np.load('../training_dataset/total_fit_data.npy')
    error_dataset = torch.from_numpy(error_dataset).float().to(device, non_blocking=True)

    y = y.to(device, non_blocking=True)
    for j in range(y.shape[0]):
        for i in range(error_dataset.shape[0]):
            error_dataset[i] = error_dataset[i] * y[j,-2*error_dataset.shape[1]:-error_dataset.shape[1]]
        all_scores = []
        for i in range(error_dataset.shape[0]):
            # print(y.shape, error_dataset[i].shape)
            scores = model(y[j], error_dataset[i])
            all_scores.append(scores)
        # 计算对应desired coverage level和置信度水平下的q值
        k_star = None
        n_xi = error_dataset.shape[0]
        # 寻找满足条件的最小 k
        for l in range(1, n_xi + 1):
            sum_value = sum([np.math.comb(n_xi, k) * (1 - alpha)**k * alpha**(n_xi - k) for k in range(l)])
            if sum_value >= 1 - 0.1: # 要求置信度为90%
                k_star = l - 1
                break
        sorted_vals, sorted_idx = torch.sort(torch.tensor(all_scores))
        all_q.append(sorted_vals[k_star])
    return torch.tensor(all_q)


class ProblemPICNN( PICNNProblem, PICNNProblemProtocol):
    def __init__(self, u_dim, bus_num, L: int, d: int, epsilon= 0.):
        PICNNProblem.__init__(self, u_dim = u_dim, bus_num = bus_num, L=L, d=d,epsilon=epsilon)
        PICNNProblemProtocol.__init__(self)