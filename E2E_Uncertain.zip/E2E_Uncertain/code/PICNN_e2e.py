"PICNN的端到端训练模型"
from collections.abc import Mapping
import io
from typing import Any

import cvxpy.error
import diffcp.cone_program
import numpy as np
import torch.utils.data
from tqdm.auto import tqdm
from torch.utils.data import TensorDataset, DataLoader
from PICNN_problem import PICNN, cal_q
from protocols import PICNNProblemProtocol


def train_e2e_epoch(
    model: PICNN,
    prob: PICNNProblemProtocol,
    cvxpylayer,
    loader: torch.utils.data.DataLoader,
    alpha: float,
    rng: np.random.Generator,
    optimizer: torch.optim.Optimizer,
    show_pbar: bool = False
) -> float:
    """Trains decision-aware quantile regression model for 1 epoch.

    Args:
        model: model to train
        prob: robust optimization problem to solve (with box constraints)
        loader: data loader
        alpha: desired coverage level
        rng: random number generator
        optimizer: optimizer to use for training
        large_q_penalty: weight for penalizing large q values
        show_pbar: whether to show a progress bar

    Returns:
        avg_task_loss: total task loss averaged over training examples for which
            the task loss was computed

    Raises:
        diffcp.cone_program.SolverError if e2e optimization problem is infeasible
    """
    assert 0 < alpha < 1  # 要求覆盖的比例
    model.train()
    # cvxpylayer = prob.get_cvxpylayer()

    total_task_loss = 0.
    total_num_tasks = 0
    # 这里需要对每个样本进行单独计算不确定性集合的size参数，然后进行梯度下降
    for y,uncertain,initial_y in tqdm(loader) if show_pbar else loader:
        batch_size = y.shape[0]
        # print(y.shape,uncertain.shape,initial_y.shape)
        q = cal_q(model,y, alpha)
        test1,test2,test3 = y.cpu().numpy().flatten(),initial_y.cpu().numpy().flatten(),q.detach().cpu().numpy().flatten()
        solution = prob.solve_cvxpylayers(y,initial_y, model, q, cvxpylayer)
        # 损失函数直接是决策变量的值
        task_loss = sum(torch.sum(x) for x in solution[0])  # 目标函数辅助变量的和
        # task_loss = sum(torch.sum((x+1)**2) for x in solution[0])  
        total_task_loss += task_loss
        total_num_tasks += batch_size

        if show_pbar:
            tqdm.write(f'task_loss: {task_loss.item()}')

            # ✅ 打印参数
        # for name, param in model.named_parameters():
        #     numel = param.data.numel()
        #     mean_val = param.data.mean().item()
        #     # 使用有偏标准差，避免单元素报 nan
        #     std_val = param.data.std(unbiased=False).item() if numel > 1 else 0.0
        #     has_nan = torch.isnan(param.data).any().item()

        #     print(f"{name}: mean={mean_val:.6f}, std={std_val:.6f}, has_nan={has_nan}")

        optimizer.zero_grad()
        task_loss.backward()
        optimizer.step()
        model.clamp_weights() # 对权重进行投影来保证凸性

    avg_task_loss = total_task_loss / total_num_tasks
    return avg_task_loss


def train_e2e(
    model: PICNN,
    loaders: Mapping[str, torch.utils.data.DataLoader],
    alpha: float,
    max_epochs: int,
    lr: float,
    l2reg: float,
    prob: PICNNProblemProtocol,
    rng: np.random.Generator,) -> tuple[PICNN, dict[str, Any]]:
    """Trains a PICNN model end-to-end (e2e) with conformal calibration.

    Uses early-stopping based on task loss on calibration set.

    Returns:
        model: trained model, on CPU
        result: dict of training results
    """
    # Initialize model
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=l2reg)
    # optimizer = torch.optim.SGD(model.parameters(), lr=lr, weight_decay=l2reg)
    buffer = io.BytesIO()
    torch.save(model.state_dict(), buffer)  # 设置缓冲区用来储存最优参数

    # Train model
    result: dict[str, Any] = {
        'train_task_losses': [],
        'best_epoch': 0,
        'train_task_loss': np.inf,  # best loss
    }
    steps_since_decrease = 0

    pbar = tqdm(range(max_epochs))
    cvxpylayer = prob.get_cvxpylayer()
    try:
        for epoch in pbar:
            # 这里先以一个样本为例做测试
            instance_num = 15
            dataset = loaders['train'].dataset

            # 检查索引是否有效
            if instance_num >= len(dataset):
                raise IndexError(f"Dataset only has {len(dataset)} samples, requested index {instance_num}")

            "获取单样本 (y, uncertain, initial_y) 先以单样本作为特例测试一下" 
            y_single, uncertain_single, initial_y_single = dataset[instance_num]
            y_batch = y_single.unsqueeze(0)           # shape: [1, ...]
            uncertain_batch = uncertain_single.unsqueeze(0)
            initial_y_batch = initial_y_single.unsqueeze(0)
            single_dataset = TensorDataset(y_batch, uncertain_batch, initial_y_batch)
            single_loader = DataLoader(single_dataset, batch_size=1, shuffle=False)

            # 记录进行梯度下降之前的参数值
            parameter = {k: v.detach().clone() for k, v in model.state_dict().items()}

            train_task_loss = train_e2e_epoch(model, prob=prob, cvxpylayer = cvxpylayer, loader=single_loader, alpha=alpha, rng=rng, optimizer=optimizer)
            
            # 这里是全部样本的测试版本
            # train_task_loss = train_e2e_epoch(model, prob=prob, loader=loaders['test'], alpha=alpha, rng=rng, optimizer=optimizer)


            result['train_task_losses'].append(train_task_loss)
            
            if train_task_loss < result['train_task_loss']:
                result['best_epoch'] = epoch
                result['train_task_loss'] = train_task_loss
                steps_since_decrease = 0
                # print(parameter)
                # buffer.seek(0)
                # torch.save(parameter, buffer)

                # ✅ 3. 保存前清空并重置 buffer
                buffer.truncate(0)
                buffer.seek(0)
                torch.save(parameter,buffer)

            
            msg = (f'Epoch {epoch}, train_task_loss {train_task_loss:.3f}')
            # print(f'Epoch {epoch}, train_task_loss {train_task_loss:.3f}')
            pbar.set_description(msg)

            steps_since_decrease += 1

            if steps_since_decrease > 100: #多少个回合没有提升就停止迭代
                break

    except (diffcp.cone_program.SolverError, cvxpy.error.SolverError) as e:
        print(f'Error: {e}')

    buffer.seek(0)
    model.load_state_dict(torch.load(buffer, weights_only=True))
    return model.cpu(), result
