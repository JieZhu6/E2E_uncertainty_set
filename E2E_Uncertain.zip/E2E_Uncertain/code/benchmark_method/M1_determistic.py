import numpy as np
import matplotlib.pyplot as plt
import cvxpy as cp
import numpy as np
from system_initial import res_forecast_data,Y_bus_matrix,PV_bus_define
from matplotlib.colors import ListedColormap, BoundaryNorm
from VVC_plot_and_viocal import plot_delta_V,cal_capacity_vio_rate,plot_PDF
import os
os.makedirs('../data', exist_ok=True)
initial_y_test = np.load('../training_dataset/initial_y_train.npy')  # 排列顺序为有功灵敏度、无功灵敏度和日前阶段的有功和无功
R_ij_matrix,X_ij_matrix = Y_bus_matrix() #节点导纳矩阵
# 这里INPUT_DIM是协信息的输入维度，U_DIM是不确定性维度
bus_num  = R_ij_matrix.shape[0]  # 节点数
TEST_HOUR = 96
PV_bus = PV_bus_define()
PV_p_forecast,PV_capcity = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据
# 优化的时候用fit的数据集 验证的时候用test
error_dataset = np.load('../training_dataset/total_fit_data.npy')  # 预测误差的历史数据  这里的误差数据是百分比数据 最后计算的时候记得乘上基准值
# 从训练集中提取出来参数
P_V_sensitity = initial_y_test[:,:len(PV_bus) * (bus_num-1)].reshape(initial_y_test.shape[0],len(PV_bus),(bus_num-1))
Q_V_sensitity = initial_y_test[:,len(PV_bus) * (bus_num-1) : 2*(len(PV_bus) * (bus_num-1))].reshape(initial_y_test.shape[0],len(PV_bus),(bus_num-1))
day_ahead_p = initial_y_test[:,2*(len(PV_bus) * (bus_num-1)) : 2*(len(PV_bus) * (bus_num-1)) + len(PV_bus)]
day_ahead_q = initial_y_test[:,2*(len(PV_bus) * (bus_num-1)) + len(PV_bus):]
# 这里先以一个样本为例画个图
instance_num = 15
day_P,day_Q,p_v,q_v = day_ahead_p[instance_num],day_ahead_q[instance_num],P_V_sensitity[instance_num],Q_V_sensitity[instance_num]
beite_cof = np.zeros(len(PV_bus))

# 假设 delta_V 已经计算好
# delta_V = np.random.rand(1000, 34) * 0.03  # 测试数据
cal_capacity_vio_rate(day_P,day_Q,beite_cof)
# plot_PDF(day_P,p_v,q_v,beite_cof)
plot_delta_V(day_P,p_v,q_v,beite_cof)

method = 1
np.save(f'../result_data/day_P_M{method}.npy',day_P)
np.save(f'../result_data/p_v_M{method}.npy',p_v)
np.save(f'../result_data/q_v_M{method}.npy',q_v)
np.save(f'../result_data/beite_cof_M{method}.npy',beite_cof)



