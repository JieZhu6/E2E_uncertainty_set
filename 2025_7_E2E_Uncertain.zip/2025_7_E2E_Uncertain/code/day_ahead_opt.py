import numpy as np
import matplotlib.pyplot as plt
from gurobipy import Model,GRB,quicksum,MVar,concatenate
import numpy as np
from benchmark_method.system_initial import res_forecast_data,case33,forecast_load,forecast_price,Y_bus_matrix,PV_bus_define
"定义系统常数"
plt.rcParams.update({'font.size': 16}) # 改变所有字体大小，改变其他性质类似
plt.rc('font',family='Times New Roman')
TEST_HOUR = 96 #仿真时长
#电价、负荷数据
SYSTEM_DATA = case33()
ACTIVE_LOAD,REACTIVE_LOAD = np.array(forecast_load(TEST_HOUR)) # 转化为标幺值
ENERGY_PRICE,RESERV_PRICE = np.array(forecast_price(TEST_HOUR))
R_ij_matrix,X_ij_matrix = Y_bus_matrix() #节点导纳矩阵
#网络拓普数据
branch = np.array(SYSTEM_DATA['branch'])
bus = np.array(SYSTEM_DATA['bus'])
V_MAX,V_MIN,branch_max = 1.05,0.95,100
# 光伏的节点
PV_bus = PV_bus_define()
PV_p_forecast,PV_capcity = res_forecast_data(TEST_HOUR,len(PV_bus))  # 光伏的功率预测数据
# VVC优化模型
model = Model('')
'光伏无功的可控范围'
pv_Q = model.addMVar((TEST_HOUR,len(PV_bus)),lb = -GRB.INFINITY,vtype = GRB.CONTINUOUS, name = 'PV_Q_power')
model.addConstr(pv_Q**2 + PV_p_forecast**2 <= PV_capcity**2 )
'平衡节点的有功和无功'
MG_Power = model.addMVar((TEST_HOUR,2),lb = 0,ub = GRB.INFINITY,vtype = GRB.CONTINUOUS, name = 'MG_power')  
"""定义二阶锥潮流约束"""
branch_current = model.addMVar((TEST_HOUR,branch.shape[0]),lb = -1*branch_max,ub = branch_max,vtype = GRB.CONTINUOUS, name=f'branch_current')
P_ij = model.addMVar((TEST_HOUR,branch.shape[0]),lb = -1*branch_max,ub = branch_max,vtype = GRB.CONTINUOUS, name=f'P_ij')
Q_ij = model.addMVar((TEST_HOUR,branch.shape[0]),lb = -1*branch_max,ub = branch_max,vtype = GRB.CONTINUOUS, name=f'Q_ij')
power_loss = model.addMVar((TEST_HOUR,branch.shape[0]),lb = -1*branch_max,ub = branch_max,vtype = GRB.CONTINUOUS, name=f'power_loss') # 记录下有功网损
"""节点的电压以及节点注入功率"""
Bus_V = model.addMVar((TEST_HOUR,bus.shape[0]),lb = V_MIN**2,ub = V_MAX**2,vtype = GRB.CONTINUOUS, name = 'Bus_V')  # 节点电压的平方
Bus_P_inj = model.addMVar((TEST_HOUR,bus.shape[0]),lb = -GRB.INFINITY,ub = GRB.INFINITY,vtype = GRB.CONTINUOUS, name = 'Bus_P_inj')
Bus_Q_inj = model.addMVar((TEST_HOUR,bus.shape[0]),lb = -GRB.INFINITY,ub = GRB.INFINITY,vtype = GRB.CONTINUOUS, name = 'Bus_P_inj')
"""平衡节点 以1节点为参考节点"""
# 平衡节点的OLTC运行约束
delta = model.addMVar(TEST_HOUR, vtype=GRB.INTEGER, lb = -2, ub = 2, name="delta")   # 分接头档位
u = model.addMVar(TEST_HOUR, vtype=GRB.CONTINUOUS, lb=0, name="u")  # 辅助变量 |delta_t - delta_{t-1}|
max_single_step,max_total_step,Vtap = 2,1,0.01  # 最大单步变动
model.addConstr(delta[0] == 0)  # 初始档位为0
for t in range(TEST_HOUR):
    if t > 1:
        # 线性化绝对值
        model.addConstr(u[t] >= delta[t] - delta[t-1])
        model.addConstr(u[t] >= delta[t-1] - delta[t])
        # 每步动作限制
        model.addConstr(u[t] <= max_single_step)
# 总操作次数约束
model.addConstr(u.sum() <= max_total_step)
# 电压关系
model.addConstr(Bus_V[:,0] == (np.ones(TEST_HOUR) + delta*Vtap)**2)
# model.addConstr(Bus_V[:,0] == np.ones(TEST_HOUR))
"二阶锥松弛的distflow潮流传输约束"
"""支路功率和节点注入电压的约束"""
for i in range(bus.shape[0]):
    # 父节点和子节点的索引
    upper_index,lower_index = np.int16(branch[np.where(branch[:, 1] == i+1)[0],0]-1),np.int16(branch[np.where(branch[:, 0] == i+1)[0],1]-1)
    # 流入支路和流出支路的索引
    upper_branch_indices,lower_branch_indices = [],[]
    for j in upper_index: # 节点i作为支路末端节点
        branch_indices = np.where((branch[:,0].astype(int) == j+1) & (branch[:,1].astype(int) == i+1))[0] # 检索支路索引
        if len(branch_indices) != 0:
            upper_branch_indices.append(branch_indices[0])  # 记录上游支路
    for j in lower_index: # 节点i作为支路末端节点
        branch_indices = np.where((branch[:,0].astype(int) == i+1) & (branch[:,1].astype(int) == j+1))[0] # 检索支路索引
        if len(branch_indices) != 0:
            lower_branch_indices.append(branch_indices[0])  # 记录下游支路            
    "计算有功功率"
    upper_flow_power,lower_flow_power = 0,0
    if len(upper_index) != 0: # 有上游节点的情况，主要是排除首节点        
        upper_flow_power += P_ij[:,upper_branch_indices].sum(axis = 1)
        for j in range(len(upper_index)):
            upper_flow_power -= R_ij_matrix[i,upper_index[j]] * branch_current[:,upper_branch_indices[j]] # 减去线路损耗
            model.addConstr(power_loss[:,upper_branch_indices[j]] == R_ij_matrix[i,upper_index[j]] * branch_current[:,upper_branch_indices[j]]) # 记录有功网损
    if len(lower_index) != 0: # 有下游节点的情况，主要是排除末端节点
        lower_flow_power += P_ij[:,lower_branch_indices].sum(axis = 1)
    model.addConstr(Bus_P_inj[:,i] == lower_flow_power - upper_flow_power) # 节点注入功率等于流出的 - 上一节点流出的 - 线路的损耗
    "计算无功功率"
    upper_flow_power,lower_flow_power = 0,0
    if len(upper_index) != 0: # 有上游节点的情况，主要是排除首节点        
        upper_flow_power += Q_ij[:,upper_branch_indices].sum(axis = 1)
        for j in range(len(upper_index)):
            upper_flow_power -= X_ij_matrix[i,upper_index[j]] * branch_current[:,upper_branch_indices[j]] # 减去线路损耗
    if len(lower_index) != 0: # 有下游节点的情况，主要是排除末端节点
        lower_flow_power += Q_ij[:,lower_branch_indices].sum(axis = 1)
    model.addConstr(Bus_Q_inj[:,i] == lower_flow_power - upper_flow_power) # 节点注入功率等于流出的 - 上一节点流出的 - 线路的损耗
"""电压降落约束，以及二阶锥松弛约束,以及转换开关的约束"""
for i in range(bus.shape[0]):
    # 这里电压降落只用考虑子节点就好
    lower_index = np.int16(branch[np.where(branch[:, 0] == i+1)[0],1]-1)
    # 流出支路的索引
    lower_branch_indices = []
    for j in lower_index: # 节点i作为支路末端节点
        branch_indices = np.where((branch[:,0].astype(int) == i+1) & (branch[:,1].astype(int) == j+1))[0] # 检索支路索引
        if len(branch_indices) != 0:
            lower_branch_indices.append(branch_indices[0])  # 记录下游支路   
    for j in range(len(lower_index)):
        # print(R_ij_matrix[i,lower_index[j]])
        drop_part1 = 2*(R_ij_matrix[i,lower_index[j]]*P_ij[:,lower_branch_indices[j]] + X_ij_matrix[i,lower_index[j]]*Q_ij[:,lower_branch_indices[j]])
        drop_part2 = (R_ij_matrix[i,lower_index[j]]**2 + X_ij_matrix[i,lower_index[j]]**2)*branch_current[:,lower_branch_indices[j]] # 网损项
        model.addConstr(Bus_V[:,lower_index[j]] == Bus_V[:,i] - drop_part1 + drop_part2)
        """支路电流、电压和有功潮流、无功潮流的平方的二阶锥松弛"""
        model.addConstr(branch_current[:,lower_branch_indices[j]] * Bus_V[:,i] >= (P_ij[:,lower_branch_indices[j]]**2 + Q_ij[:,lower_branch_indices[j]]**2))
"节点注入功率平衡约束"
count_PV = 0
for i in range(bus.shape[0]):
    if i == 0:
        model.addConstr(Bus_P_inj[:,i] == MG_Power[:,0] - ACTIVE_LOAD[i,:])
        model.addConstr(Bus_Q_inj[:,i] == MG_Power[:,1] - REACTIVE_LOAD[i,:])
    elif np.isin(i+1,PV_bus): # PV连接节点
        model.addConstr(Bus_P_inj[:,i] == PV_p_forecast[:,count_PV] - ACTIVE_LOAD[i,:])
        model.addConstr(Bus_Q_inj[:,i] == pv_Q [:,count_PV] - REACTIVE_LOAD[i,:])
        count_PV += 1
    else:
        model.addConstr(Bus_P_inj[:,i] == - ACTIVE_LOAD[i,:])
        model.addConstr(Bus_Q_inj[:,i] == - REACTIVE_LOAD[i,:])

# 目标函数最小化网损
obj = power_loss.sum()
model.setObjective(obj,GRB.MINIMIZE)  #除了原上层模型目标函数其余皆为负号
model.setParam('MIPGap',0.01)
model.optimize()
# model.computeIIS()
# model.write("model.ilp")
# 检验一下功率是否平衡：
print("power_loss:",np.sum(power_loss.X))
print(np.sum(ACTIVE_LOAD) - np.sum(PV_p_forecast) - np.sum(MG_Power[:,0].X))
print(delta.X)
slack_gap = np.zeros((TEST_HOUR,branch.shape[0]))# 记录一下二阶锥松弛的松弛间隙和网损
for i in range(bus.shape[0]):
    # 这里电压降落只用考虑子节点就好
    lower_index = np.int16(branch[np.where(branch[:, 0] == i+1)[0],1]-1)
    # 流出支路的索引
    lower_branch_indices = []
    for j in lower_index: # 节点i作为支路末端节点
        branch_indices = np.where((branch[:,0].astype(int) == i+1) & (branch[:,1].astype(int) == j+1))[0] # 检索支路索引
        if len(branch_indices) != 0:
            lower_branch_indices.append(branch_indices[0])  # 记录下游支路   
    for j in range(len(lower_index)):
        slack_gap[:,lower_branch_indices[j]] = branch_current[:,lower_branch_indices[j]].X * Bus_V[:,i].X - (P_ij[:,lower_branch_indices[j]].X**2 + Q_ij[:,lower_branch_indices[j]].X**2)
# print(np.sum(slack_gap))
def plot(power,v,line):
    if power == 1:
        plt.figure(figsize=(8,6))
        for i in range(len(PV_bus)):
            # plt.plot(np.arange(TEST_HOUR),pv_Q[:,i].X,label = f'PV_P{i}')
            # plt.plot(np.arange(TEST_HOUR),PV_p_forecast[:,i],label = f'PV_Q{i}')
            plt.plot(np.arange(TEST_HOUR),pv_Q[:,i].X **2 + PV_p_forecast[:,i]**2,label = f'PV{PV_bus[i]}')
        plt.hlines(y=PV_capcity **2,xmin=0,xmax=TEST_HOUR,colors = 'r',linestyles = '--',label = 'PV capacity')
        # plt.plot(np.arange(TEST_HOUR),np.sum(PV_p_forecast,axis = 1),label = 'PV_P')
        # plt.plot(np.arange(TEST_HOUR),np.sum(ACTIVE_LOAD,axis = 0),label = 'Load')
        # plt.plot(np.arange(TEST_HOUR),MG_Power.X[:,0],label = 'MG')
        # plt.plot(np.arange(TEST_HOUR),MG_Power.X[:,0] + np.sum(PV_p_forecast,axis = 1) - np.sum(power_loss.X,axis=1) - np.sum(ACTIVE_LOAD,axis = 0),label = 'MG')
        # plt.plot(np.arange(TEST_HOUR),MG_Power.X[:,0] + np.sum(PV_p_forecast,axis = 1),label = 'loss')
        # plt.plot(np.arange(TEST_HOUR),MG_Power.X[:,0] + np.sum(PV_p_forecast,axis = 1),label = 'MG')
        # plt.legend()
        plt.xlabel('time (1h)')
        plt.ylabel('Power (MW)')
        plt.figure(figsize=(8,6))
        for i in range(len(PV_bus)):
            plt.plot(np.arange(TEST_HOUR),pv_Q[:,i].X,label = f'PV_Q{PV_bus[i]}')
            # plt.plot(np.arange(TEST_HOUR),PV_p_forecast[:,i],label = f'PV_Q{PV_bus[i]}')
        plt.plot(np.arange(TEST_HOUR),Bus_V[:,-1].X,label = f'V')
        plt.legend()
        plt.xlabel('time (1h)')
        plt.ylabel('Power (MW)')
    if v == 1:
        #节点电压的三维图像
        busv = np.array(np.sqrt(Bus_V.X))
        # 创建一个 3D 图像
        fig = plt.figure(figsize=(8,6))
        ax = fig.add_subplot(111, projection='3d')
        # 创建 x 和 y 的网格
        y = np.arange(0, TEST_HOUR, 1)
        x = np.arange(0, 33, 1)
        X, Y = np.meshgrid(x, y)
        Z = busv
        # 创建表面图
        surf = ax.plot_surface(X, Y, Z, cmap='viridis')
        # 设置 x 轴和 y 轴标签
        ax.set_xlabel('bus')
        ax.set_ylabel('time')
        ax.set_zlabel('voltage')
        # 添加颜色条
    if line == 1: #画线损的三维图像
        loss = np.array(power_loss.X)
        # 创建一个 3D 图像
        fig = plt.figure(figsize=(8,6))
        ax = fig.add_subplot(111, projection='3d')
        # 创建 x 和 y 的网格
        y = np.arange(0, TEST_HOUR, 1)
        x = np.arange(0, power_loss.shape[1], 1)
        X, Y = np.meshgrid(x, y)
        Z = loss 
        # 创建表面图
        surf = ax.plot_surface(X, Y, Z, cmap='viridis')
        # 设置 x 轴和 y 轴标签
        ax.set_xlabel('line')
        ax.set_ylabel('time')
        ax.set_zlabel('line loss')
        # 添加颜色条
    plt.show()
plot(1,1,1)